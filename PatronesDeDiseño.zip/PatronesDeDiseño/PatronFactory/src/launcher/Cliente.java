package launcher;

import figuras.Circle;
import figuras.Square;
import figuras.IShape;
import figuras.ShapeFactory;

public class Cliente {
	
	public static void main(String[]args) {
		
		
		IShape c = ShapeFactory.getShape(0);
		
		c.setR(10);
 		
		System.out.println(c.darArea());
		
	}
}
