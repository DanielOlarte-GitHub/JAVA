package figuras;

public interface IShape {
	
	public double darArea();
	public void setR(int r);
	
	
	
}
