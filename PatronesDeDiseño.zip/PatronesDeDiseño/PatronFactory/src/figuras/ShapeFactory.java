package figuras;

public class ShapeFactory {
	
	public static IShape getShape(int i) {
		
		IShape shapes[] = {new Circle(), new Square()};
		
		if(i==shapes.length) {
			return shapes[i];
		}else {
			return null;
		}
		
	}
}
