package launcher;

import java.util.HashMap;

public class Connection {
	public  String msg = "";
	private static Connection[] rutas = new Connection [1000];	
	
	private HashMap<String, Client> coleccionEstudiante = new HashMap<String, Client>();
	
	private Connection(int grupo) {
		System.out.println("\nSe ha creado el grupo: " + grupo);
		
	}
	
	public static Connection getConnection(int grupo) {
		
		if(rutas[grupo]==null) {
			rutas[grupo] = new Connection(grupo);
		}
		
		return rutas[grupo];
	
		
	}
	
	public void imprimirMSG() {
		System.out.println(msg);
	}
}
