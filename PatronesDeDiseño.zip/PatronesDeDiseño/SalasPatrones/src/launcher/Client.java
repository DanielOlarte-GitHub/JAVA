package launcher;

import java.util.Scanner;

public class Client {
	public static void main(String[]args) {
		Scanner leer = new Scanner(System.in);
		int grupoCl;
		System.out.println("Esta en el grupo principal!\n");
		
		//grupoCl = leer.nextInt();
		Connection c1 = Connection.getConnection(1);
		c1.msg="Ha ingresado al grupo 1";
		System.out.println("La ruta del grupo 1 es: "+c1.toString());
		c1.imprimirMSG();
		
		c1 = Connection.getConnection(1);
		c1.msg="Ha ingresado al grupo 1";
		System.out.println("La ruta del grupo 1 es: "+c1.toString());
		c1.imprimirMSG();
		
		
		c1 = Connection.getConnection(2);
		c1.msg="Ha ingresado al grupo 2";
		System.out.println("La ruta del grupo 2 es: "+c1.toString());
		c1.imprimirMSG();	
		
		c1 = Connection.getConnection(7);
		c1.msg="Ha ingresado al grupo 7";
		System.out.println("La ruta del grupo 2 es: "+c1.toString());
		c1.imprimirMSG();	
		
		c1 = Connection.getConnection(7);
		c1.msg="Ha ingresado al grupo 7";
		System.out.println("La ruta del grupo 2 es: "+c1.toString());
		c1.imprimirMSG();	
		
	}
}
