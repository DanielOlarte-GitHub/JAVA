package buiderPattern;

public interface IBuilderSandwich extends IBuilder {

	public void putPan();
	public void putAtun();
	public void putLechuga();
}
