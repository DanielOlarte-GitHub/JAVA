package buiderPattern;

import products.Pizza;

public class PizzaBuilder implements IBuilderPizza{

	private Pizza pizza;
	
	public void reset() {
		pizza=new Pizza();
	}
	
	

	@Override
	public void putJamon() {
		pizza.setJamon(true);
	}

	@Override
	public void putMasa() {
		pizza.setMasa(true);
	}

	
	@Override
	public void putSalsa() {
		pizza.setSalsa(true);
		
	}

	@Override
	public void putPepinillos() {
		pizza.setPepinillos(true);
	}

	@Override
	public void putPina() {
		pizza.setPina(true);
	}

	@Override
	public void putQueso() {
		pizza.setQueso(true);
	}
	
	public Pizza getProduct() {
		return this.pizza;
	}

}
