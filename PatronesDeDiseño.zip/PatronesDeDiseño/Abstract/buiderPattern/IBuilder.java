package buiderPattern;

public interface IBuilder {

	public void putJamon();
	public void putSalsa();
	public void putPina();
	public void putQueso();
	public void putPepinillos();
	

}
