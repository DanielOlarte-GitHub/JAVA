package buiderPattern;

public interface IBuilderPizza extends IBuilder {
	public void putMasa();

}
