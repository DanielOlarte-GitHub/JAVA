package buiderPattern;

import products.Pizza;
import products.Sandwich;

public class SandwichBuilder implements IBuilderSandwich{

	private Sandwich sandwich;
	
	public void reset() {
		sandwich=new Sandwich();
	}
	
	@Override
	public void putLechuga() {
		sandwich.setLechuga(true);
	}

	@Override
	public void putJamon() {
		sandwich.setJamon(true);
	}

	

	@Override
	public void putPan() {
		sandwich.setPan(true);
	}

	@Override
	public void putAtun() {
		sandwich.setAtun(true);
		
	}

	@Override
	public void putSalsa() {
		sandwich.setSalsa(true);
		
	}

	@Override
	public void putPepinillos() {
		sandwich.setPepinillos(true);
	}

	@Override
	public void putPina() {
		sandwich.setPina(true);
	}

	@Override
	public void putQueso() {
		sandwich.setQueso(true);
	}
	
	public Sandwich getProduct() {
		return this.sandwich;
	}

	
}
