module Abstract {
}