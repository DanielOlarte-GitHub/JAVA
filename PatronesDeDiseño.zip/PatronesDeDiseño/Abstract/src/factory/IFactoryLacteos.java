package factory;

import products.queso.*;
import products.yogurt.*;

public interface IFactoryLacteos {
	
	public IQueso darQueso();
	public IYogurt darYogurt();
	
}
