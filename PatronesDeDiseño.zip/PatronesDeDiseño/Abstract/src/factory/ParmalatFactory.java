package factory;

import products.queso.IQueso;
import products.queso.QuesoParmalat;
import products.yogurt.IYogurt;
import products.yogurt.YogurtParmalat;

public class ParmalatFactory implements IFactoryLacteos{
	
	@Override
	public IQueso darQueso() {
		// TODO Auto-generated method stub
		return new QuesoParmalat();
	}
	
	@Override
	public IYogurt darYogurt() {
		return new YogurtParmalat();
	}
}
