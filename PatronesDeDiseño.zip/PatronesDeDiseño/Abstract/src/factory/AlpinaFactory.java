package factory;

import products.queso.IQueso;
import products.queso.QuesoAlpina;
import products.yogurt.IYogurt;
import products.yogurt.YogurtAlpina;

public class AlpinaFactory implements IFactoryLacteos{
	
	@Override
	public IQueso darQueso() {
		// TODO Auto-generated method stub
		return new QuesoAlpina();
	}
	
	@Override
	public IYogurt darYogurt() {
		// TODO Auto-generated method stub
		return new YogurtAlpina();
	}
}
