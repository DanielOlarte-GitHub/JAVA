package launcher;
import factory.AlpinaFactory;
import factory.IFactoryLacteos;
import products.queso.*;
import products.queso.IQueso;
import products.yogurt.IYogurt;
import products.yogurt.YogurtAlpina;

public class Client {
	
	public static void main(String[]args) {
		
		IFactoryLacteos factory = new AlpinaFactory();
		
		
		IQueso queso = factory.darQueso();
		IYogurt yogurt = factory.darYogurt();
		
		System.out.println(queso.marcaQueso());
		System.out.println(yogurt.marcaYogurt());
		
	}
	
}
