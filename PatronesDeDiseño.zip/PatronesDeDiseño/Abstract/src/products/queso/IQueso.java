package products.queso;

public interface IQueso {
	public String marcaQueso();
}
