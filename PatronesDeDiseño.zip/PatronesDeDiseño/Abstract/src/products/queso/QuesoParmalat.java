package products.queso;

public class QuesoParmalat implements IQueso{
	@Override
	public String marcaQueso() {
		// TODO Auto-generated method stub
		return null;
	}
}
