package products.yogurt;

public class YogurtAlpina implements IYogurt{
	@Override
	public String marcaYogurt() {
		
		return null;
	}
}
