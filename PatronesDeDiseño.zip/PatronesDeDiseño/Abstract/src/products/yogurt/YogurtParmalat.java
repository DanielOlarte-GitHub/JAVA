package products.yogurt;

public class YogurtParmalat implements IYogurt{
	@Override
	public String marcaYogurt() {
		// TODO Auto-generated method stub
		return null;
	}
}
