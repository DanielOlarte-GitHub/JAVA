package products.yogurt;

public interface IYogurt {
	public String marcaYogurt();
}
