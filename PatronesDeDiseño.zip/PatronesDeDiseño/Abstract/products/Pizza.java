package products;

public class Pizza {
	
	private boolean jamon=false;
	private boolean masa=false;
	
	private boolean salsa=false;
	private boolean pepinillos=false;
	private boolean pina=false;
	private boolean queso=false;
	
	
	public String toString() {
		
		String resultado="";
		
		if(jamon)
		resultado+=" jamon";
		
		if(masa)
			resultado+=" masa";
		
		if(salsa)
			resultado+=" salsa";
		
		if(pepinillos)
			resultado+=" pepinillos";
		
		if(pina)
			resultado+=" pina";
		
		if(queso)
			resultado+=" queso";
				
		return resultado;
	}
	
	public boolean isJamon() {
		return jamon;
	}
	public void setJamon(boolean jamon) {
		this.jamon = jamon;
	}
	public boolean isMasa() {
		return masa;
	}
	public void setMasa(boolean masa) {
		this.masa = masa;
	}
	
	
	public boolean isSalsa() {
		return salsa;
	}
	public void setSalsa(boolean salsa) {
		this.salsa = salsa;
	}
	public boolean isPepinillos() {
		return pepinillos;
	}
	public void setPepinillos(boolean pepinillos) {
		this.pepinillos = pepinillos;
	}
	public boolean isPina() {
		return pina;
	}
	public void setPina(boolean pina) {
		this.pina = pina;
	}
	public boolean isQueso() {
		return queso;
	}
	public void setQueso(boolean queso) {
		this.queso = queso;
	}

	
}
