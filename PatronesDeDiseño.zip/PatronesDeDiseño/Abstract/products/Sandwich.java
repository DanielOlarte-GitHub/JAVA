package products;

public class Sandwich {
	
	private boolean lechuga =false;
	private boolean jamon=false;
	
	private boolean pan=false;
	private boolean atun=false;
	private boolean salsa=false;
	private boolean pepinillos=false;
	private boolean pina=false;
	private boolean queso=false;
	
	public boolean isLechuga() {
		return lechuga;
	}
	public void setLechuga(boolean lechuga) {
		this.lechuga = lechuga;
	}
	public boolean isJamon() {
		return jamon;
	}
	public void setJamon(boolean jamon) {
		this.jamon = jamon;
	}
	
	public boolean isPan() {
		return pan;
	}
	public void setPan(boolean pan) {
		this.pan = pan;
	}
	public boolean isAtun() {
		return atun;
	}
	public void setAtun(boolean atun) {
		this.atun = atun;
	}
	public boolean isSalsa() {
		return salsa;
	}
	public void setSalsa(boolean salsa) {
		this.salsa = salsa;
	}
	public boolean isPepinillos() {
		return pepinillos;
	}
	public void setPepinillos(boolean pepinillos) {
		this.pepinillos = pepinillos;
	}
	public boolean isPina() {
		return pina;
	}
	public void setPina(boolean pina) {
		this.pina = pina;
	}
	public boolean isQueso() {
		return queso;
	}
	public void setQueso(boolean queso) {
		this.queso = queso;
	}

	
}
