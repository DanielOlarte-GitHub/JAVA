package launcher;

import buiderPattern.PizzaBuilder;
import products.Pizza;
import products.Sandwich;

public class Client {
	
	public static void main(String[] args) {
		

		Director d=new Director();
		Pizza vale=d.getDeliciosa();
		Pizza juanAndres=d.getHawaiana();
		Sandwich daniel=d.getPoderoso();
		
		System.out.println("la pizza de vale tiene: ");
		System.out.println(vale.toString());
		
		
		
		
		
	}

}
