package launcher;

import buiderPattern.IBuilder;
import buiderPattern.PizzaBuilder;
import buiderPattern.SandwichBuilder;
import products.Pizza;
import products.Sandwich;

public class Director {
	

	public Pizza getHawaiana() {
		PizzaBuilder pb=new PizzaBuilder();
		pb.reset();
		pb.putMasa();
		pb.putQueso();
		pb.putPina();
		pb.putJamon();
		return pb.getProduct();
		
	}
	
	public Pizza getDeliciosa() {
	
		PizzaBuilder pb=new PizzaBuilder();
		pb.reset();
		pb.putMasa();
		pb.putQueso();
		pb.putPepinillos();
		return pb.getProduct();
	}
	
	public Sandwich getPoderoso() {
		SandwichBuilder sb=new SandwichBuilder();
		sb.reset();
		sb.putPan();
		sb.putJamon();
		sb.putQueso();
		sb.putPepinillos();
		
		return sb.getProduct();
	}

}
