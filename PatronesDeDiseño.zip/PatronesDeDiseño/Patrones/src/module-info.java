module Paradigmas {
}