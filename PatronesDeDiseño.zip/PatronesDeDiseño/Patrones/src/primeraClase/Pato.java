package primeraClase;

public abstract class Pato {
	public String nombre = "Pedro";
	public int edad;
	public String color;

	public abstract String hacerSonido();
	
	public String darNombre() {
		return nombre;
	}
}
