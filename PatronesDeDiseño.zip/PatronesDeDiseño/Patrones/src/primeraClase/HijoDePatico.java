package primeraClase;

public class HijoDePatico extends Patico{
	
}
