package primeraClase;

public class Patico extends Pato implements FuncionesVitales{
	public Patico() {
		
	}
	
	public String hacerSonido() {
		return "Cuack";
	}

	@Override
	public String comer() {
		return "El pato come";
	}

	@Override
	public String respirar() {
		return "El pato respira";
	}

	@Override
	public String defecar() {
		return "El pato defeca";
	}
}
