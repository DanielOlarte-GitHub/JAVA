package primeraClase;

public class PatoDeHule extends Pato{
	public String marca = "Fisher Price";
	
	public String hacerSonido() {
		return "Soy un pato de hule";
	}
}
