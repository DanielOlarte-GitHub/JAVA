package primeraClase;

public class Main {
	public static void main(String[]args) {
		System.out.println("Hola Mundo");
		Pato p = new Patico();
		Patico pt = new Patico();
		pt.nombre = "Lucas jr";
		Pato ph = new PatoDeHule();
		System.out.println();
		HijoDePatico Hp = new HijoDePatico();
		System.out.println(Hp.comer());
		
	}
}
