package primeraClase;

public interface FuncionesVitales {
	public String comer();
	
	public String respirar();
	
	public String defecar();
}
