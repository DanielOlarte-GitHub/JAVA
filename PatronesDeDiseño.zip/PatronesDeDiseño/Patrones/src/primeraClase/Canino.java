package primeraClase;

public abstract class Canino {
	public abstract String hacerSonido();
	
	public String nombre() {
		return "";
	}
}
