package primeraClase;

public class Perro extends Canino implements FuncionesVitales{
	public String hacerSonido() {
		return "Guau";
	}

	@Override
	public String comer() {
		return "El perro come";
	}

	@Override
	public String respirar() {
		return "El perro respira";
	}

	@Override
	public String defecar() {
		return "El perro defeca";
	}
}
