package launcher;

import products.Blister;
import products.EmbaseJarabe;
import products.EmbaseVacuna;
import products.Jeringa;

public class Client {
	
	public static void main(String[]args) {
		Director d = new Director();
		EmbaseJarabe emja1 = d.gripa();
		Jeringa jer1 = d.Influenza();
		Blister bl1 = d.dolorCabeza();
		EmbaseVacuna evB = d.covidV();
 		
		
		System.out.println("La jeringa de covid tiene: \n");
		System.out.println(jer1.toString());
		
	}

}
