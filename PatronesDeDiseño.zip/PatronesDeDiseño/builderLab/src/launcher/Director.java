package launcher;

import buiderPattern.BlisterBuilder;
import buiderPattern.EmbaseJarabeBuilder;
import buiderPattern.EmbaseVacunaBuilder;
import buiderPattern.JeringaBuilder;
import products.Blister;
import products.EmbaseJarabe;
import products.EmbaseVacuna;
import products.Jeringa;

public class Director {

	public Jeringa covidJ() {
		JeringaBuilder jb = new JeringaBuilder();
		jb.reset();
		jb.putAguja();
		jb.putCapuchon();
		jb.putEmbolo();
		jb.putEmpaque();
		jb.putEtiqueta();
		jb.putPiston();
		jb.putPivote();
		jb.putTubo();
		
		return jb.getProduct();
	}
	
	public Jeringa Tetano() {
		JeringaBuilder jb = new JeringaBuilder();
		jb.reset();
		jb.putAguja();
		jb.putCapuchon();
		jb.putEmbolo();
		jb.putEmpaque();
		jb.putEtiqueta();
		jb.putPiston();
		jb.putPivote();
		jb.putTubo();
		
		return jb.getProduct();
	}
	
	public Jeringa Influenza() {
		JeringaBuilder jb = new JeringaBuilder();
		jb.reset();
		jb.putAguja();
		jb.putCapuchon();
		jb.putEmbolo();
		jb.putEmpaque();
		jb.putEtiqueta();
		jb.putPiston();
		jb.putPivote();
		jb.putTubo();
		
		return jb.getProduct();
	}
	
	public EmbaseJarabe gripa() {
		EmbaseJarabeBuilder ej = new EmbaseJarabeBuilder();
		ej.reset();
		ej.putEmpaque();
		ej.putEtiqueta();
		ej.putFrasco();
		ej.putTapa();
		
		
		return ej.getProduct();
	}
	
	public Blister dolorCabeza() {
		BlisterBuilder bl = new BlisterBuilder();
		bl.reset();
		bl.putEmpaque();
		bl.putEtiqueta();
		bl.putCavidades();
		bl.putBaseAluminio();
		
		return bl.getProduct();
		
	}
	
	public EmbaseVacuna covidV() {
		EmbaseVacunaBuilder evB = new EmbaseVacunaBuilder();
		evB.reset();
		evB.putEmpaque();
		evB.putEtiqueta();
		evB.putFrasco();
		evB.putTapa();
		
		
		return evB.getProduct();
	}
}
