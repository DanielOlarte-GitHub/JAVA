package buiderPattern;

import products.Blister;

public class BlisterBuilder implements IBuilderBlister{

	private Blister blister;
	
	public void reset() {
		blister = new Blister();
	}

	@Override
	public void putEtiqueta() {
		blister.setEtiqueta(true);
		
	}

	@Override
	public void putEmpaque() {
		blister.setEmpaque(true);
		
	}

	@Override
	public void putCavidades() {
		blister.setCavidades(true);
		
	}

	@Override
	public void putBaseAluminio() {
		blister.setBaseAlmunio(true);
		
	}
	
	public Blister getProduct() {
		return this.blister;
	}
	
}
