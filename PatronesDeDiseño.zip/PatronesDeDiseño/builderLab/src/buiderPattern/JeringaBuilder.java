package buiderPattern;

import products.Jeringa;

public class JeringaBuilder implements IBuilderJeringa{
	
	private Jeringa jeringa;
	
	public void reset() {
		jeringa = new Jeringa();
	}

	@Override
	public void putEtiqueta() {
		jeringa.setEtiqueta(true);
		
	}

	@Override
	public void putEmpaque() {
		jeringa.setEmpaque(true);
		
	}

	@Override
	public void putAguja() {
		jeringa.setAguja(true);
		
	}

	@Override
	public void putCapuchon() {
		jeringa.setCapuchon(true);
		
	}

	@Override
	public void putTubo() {
		jeringa.setTubo(true);
		
	}

	@Override
	public void putEmbolo() {
		jeringa.setEmbolo(true);
		
	}

	@Override
	public void putPiston() {
		jeringa.setPiston(true);
		
	}

	@Override
	public void putPivote() {
		jeringa.setPivote(true);
		
	}
	
	public Jeringa getProduct() {
		return this.jeringa;
	}
	
	
}
