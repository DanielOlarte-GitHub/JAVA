package buiderPattern;


public interface IBuilder {

	public void putEtiqueta();
	public void putEmpaque();
	
		
	
}
