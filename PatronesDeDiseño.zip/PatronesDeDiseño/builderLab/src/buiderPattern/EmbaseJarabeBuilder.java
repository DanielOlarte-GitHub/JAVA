package buiderPattern;

import products.EmbaseJarabe;

public class EmbaseJarabeBuilder implements IBuilderEmbaseJarabe{
	
	private EmbaseJarabe embaseJarabe;
	
	public void reset() {
		embaseJarabe = new EmbaseJarabe();
	}
	
	@Override
	public void putEtiqueta() {
		embaseJarabe.setEtiqueta(true);
		
	}

	@Override
	public void putEmpaque() {
		embaseJarabe.setEmpaque(true);
		
	}

	@Override
	public void putFrasco() {
		embaseJarabe.setFrasco(true);
		
	}

	@Override
	public void putTapa() {
		embaseJarabe.setTapa(true);
		
	}
	
	public EmbaseJarabe getProduct() {
		return this.embaseJarabe;
	}
	
}
