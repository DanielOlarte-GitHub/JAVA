package buiderPattern;

public interface IBuilderEmbaseVacuna extends IBuilder{

	public void putFrasco();
	public void putTapa();
	
}
