package buiderPattern;

import products.EmbaseVacuna;

public class EmbaseVacunaBuilder implements IBuilderEmbaseVacuna{
	private EmbaseVacuna embaseVacuna;
	
	public void reset() {
		embaseVacuna = new EmbaseVacuna();
	}
	
	@Override
	public void putEtiqueta() {
		embaseVacuna.setEtiqueta(true);
		
	}

	@Override
	public void putEmpaque() {
		embaseVacuna.setEmpaque(true);
		
	}

	@Override
	public void putFrasco() {
		embaseVacuna.setFrasco(true);
		
	}

	@Override
	public void putTapa() {
		embaseVacuna.setTapa(true);
		
	}
	
	public EmbaseVacuna getProduct() {
		return this.embaseVacuna;
	}
}
