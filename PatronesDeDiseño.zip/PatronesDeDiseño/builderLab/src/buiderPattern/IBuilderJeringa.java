package buiderPattern;

public interface IBuilderJeringa extends IBuilder{
	
	public void putAguja();
	public void putCapuchon();
	public void putTubo();
	public void putEmbolo();
	public void putPiston();
	public void putPivote();
	
	
}
