package buiderPattern;

public interface IBuilderBlister extends IBuilder{
	
	public void putCavidades();
	public void putBaseAluminio();
	
}
