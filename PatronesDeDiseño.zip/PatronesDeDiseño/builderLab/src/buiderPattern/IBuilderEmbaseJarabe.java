package buiderPattern;

public interface IBuilderEmbaseJarabe extends IBuilder{
	
	public void putFrasco();
	public void putTapa();
	
	
}
