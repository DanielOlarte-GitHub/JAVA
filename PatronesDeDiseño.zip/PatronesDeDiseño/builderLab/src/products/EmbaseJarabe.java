package products;

public class EmbaseJarabe {

	private boolean Etiqueta = false;
	private boolean Empaque = false;
	private boolean Frasco = false;
	private boolean Tapa = false;
	
	
	public String toString() {
		
		String resultado = "";
		
		if(Etiqueta)
			resultado+=" Etiqueta";
			
		if(Empaque)
			resultado+=" Empaque";
			
		if(Frasco)
			resultado+=" Frasco";
		
		if(Tapa)
			resultado+=" Tapa";
		
		
		return resultado;
	}


	public boolean isEtiqueta() {
		return Etiqueta;
	}


	public void setEtiqueta(boolean etiqueta) {
		Etiqueta = etiqueta;
	}


	public boolean isEmpaque() {
		return Empaque;
	}


	public void setEmpaque(boolean empaque) {
		Empaque = empaque;
	}


	public boolean isFrasco() {
		return Frasco;
	}


	public void setFrasco(boolean frasco) {
		Frasco = frasco;
	}


	public boolean isTapa() {
		return Tapa;
	}


	public void setTapa(boolean tapa) {
		Tapa = tapa;
	}
	
	
	
	
}
