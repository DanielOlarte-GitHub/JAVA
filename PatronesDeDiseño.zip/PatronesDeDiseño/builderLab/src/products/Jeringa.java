package products;

public class Jeringa {
	
	private boolean Etiqueta = false;
	private boolean Empaque = false;
	private boolean Aguja = false;
	private boolean Capuchon = false;
	private boolean Tubo = false;
	private boolean Embolo = false;
	private boolean Piston = false;
	private boolean Pivote = false;

	
	public String toString() {
		
		String resultado = "";
		
		if(Etiqueta)
			resultado+="*  Etiqueta\n";
			
		if(Empaque)
			resultado+="*  Empaque\n";
			
		if(Aguja)
			resultado+="*  Aguja\n";
		
		if(Capuchon)
			resultado+="*  Capuchon\n";
		
		if(Tubo)
			resultado+="*  Tubo\n";
		
		if(Embolo)
			resultado+="*  Embolo\n";
		
		if(Piston)
			resultado+="*  Piston\n";
		
		if(Pivote)
			resultado+="*  Pivote\n";
				
		return resultado;		
	}


	public boolean isEtiqueta() {
		return Etiqueta;
	}


	public void setEtiqueta(boolean etiqueta) {
		Etiqueta = etiqueta;
	}


	public boolean isEmpaque() {
		return Empaque;
	}


	public void setEmpaque(boolean empaque) {
		Empaque = empaque;
	}


	public boolean isAguja() {
		return Aguja;
	}


	public void setAguja(boolean aguja) {
		Aguja = aguja;
	}


	public boolean isCapuchon() {
		return Capuchon;
	}


	public void setCapuchon(boolean capuchon) {
		Capuchon = capuchon;
	}


	public boolean isTubo() {
		return Tubo;
	}


	public void setTubo(boolean tubo) {
		Tubo = tubo;
	}


	public boolean isEmbolo() {
		return Embolo;
	}


	public void setEmbolo(boolean embolo) {
		Embolo = embolo;
	}


	public boolean isPiston() {
		return Piston;
	}


	public void setPiston(boolean piston) {
		Piston = piston;
	}


	public boolean isPivote() {
		return Pivote;
	}


	public void setPivote(boolean pivote) {
		Pivote = pivote;
	}
	
}
