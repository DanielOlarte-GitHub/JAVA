package products;

public class Blister {
	
	private boolean Etiqueta = false;
	private boolean Empaque = false;
	private boolean Cavidades = false;
	private boolean BaseAlmunio = false;
	
	
	public String toString() {
		
		String resultado = "";
		
		if(Etiqueta)
			resultado+=" Etiqueta";
			
		if(Empaque)
			resultado+=" Empaque";
			
		if(Cavidades)
			resultado+=" Cavidades";
		
		if(BaseAlmunio)
			resultado+=" BaseAlmunio";
		
		
		return resultado;
	}


	public boolean isEtiqueta() {
		return Etiqueta;
	}


	public void setEtiqueta(boolean etiqueta) {
		Etiqueta = etiqueta;
	}


	public boolean isEmpaque() {
		return Empaque;
	}


	public void setEmpaque(boolean empaque) {
		Empaque = empaque;
	}


	public boolean isCavidades() {
		return Cavidades;
	}


	public void setCavidades(boolean cavidades) {
		Cavidades = cavidades;
	}


	public boolean isBaseAlmunio() {
		return BaseAlmunio;
	}


	public void setBaseAlmunio(boolean baseAlmunio) {
		BaseAlmunio = baseAlmunio;
	}

	
	

}
