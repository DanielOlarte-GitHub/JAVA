package launcher;

public class Aja {
	Connection k = Connection.getConnection();
	public void metodoX() {
		
		
		System.out.println(k.toString());
		System.out.println(k.msg);
		k.msg="Segundo Cambio";
	}
	
	public void showMessage() {
		System.out.println(k.toString());
		System.out.println(k.msg);
	}
}
