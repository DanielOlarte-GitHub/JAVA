package launcher;

public class Connection {
	public  String msg = "Esto es una instancia!";
	
	private static Connection c;
	
	private Connection() {
		System.out.println("Creaste instancia!");
	}
	
	public static Connection getConnection() {
		if(c==null) {
			c=new Connection();
		}
		return c;
	}
	
	public  void cambiarMsg() {
		msg="ahora cambie";
	}
	
}
