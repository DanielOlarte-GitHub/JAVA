package launcher;

public class Client {
	public static void main(String[]args) {
		
		Connection c = Connection.getConnection();
		System.out.println(c.toString());
		c.msg="Primer Cambio";
		
		c = Connection.getConnection();
		System.out.println(c.toString());
		System.out.println(c.msg);
		
		//Aja a = new Aja();
		//a.metodoX();
		
		System.out.println(c.toString());
		System.out.println(c.msg);
		
		c.cambiarMsg();
		
		System.out.println(c.toString());
		System.out.println(c.msg);
	
		//a.showMessage();
	}
}
