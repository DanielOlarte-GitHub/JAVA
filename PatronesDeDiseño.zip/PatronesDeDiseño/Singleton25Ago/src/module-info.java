module Singleton25Ago {
}