package codigo;

import java.util.ArrayList;
import java.util.List;

public class Tienda implements Sujeto {
    private List<Observador> clientes = new ArrayList<>();

    @Override
    public void agregarSubscripcion(Observador cliente) {
        clientes.add(cliente);
    }
    @Override
    public void eliminarSubscripcion(Observador cliente) {
        clientes.remove(cliente);
    }
    @Override
    public void notificarSubscripciones() {
        System.out.println("Un nuevo item esta en venta! Actua rapido antes que se venda!");
        for(Observador clientee: clientes) {
            clientee.actualizar("Vendido!");
        }
    }
}
