package codigo;

public class ClienteAdictoAlasCompras implements Observador {
    @Override
    public void actualizar(String mensaje) {
        procesoDeMensaje(mensaje);
    }
    private void procesoDeMensaje(String mensaje) {
        System.out.println("\nCliente adicto a las compras esta interesado en comprar el producto que esta a la venta!");
        
    }
}
