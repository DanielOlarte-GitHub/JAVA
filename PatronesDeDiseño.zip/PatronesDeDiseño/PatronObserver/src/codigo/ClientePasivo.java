package codigo;

public class ClientePasivo implements Observador {
    @Override
    public void actualizar(String mensaje) {
        System.out.println("\nEl cliente pasivo a realizado un comentario de la venta.");
    }
}
