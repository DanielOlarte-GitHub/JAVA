package codigo;

public class Cliente {
	public static void main(String[] args) {
		
	    Tienda tienda = new Tienda();
	    Observador cliente1 = new ClientePasivo();
	    Observador cliente2 = new ClienteAdictoAlasCompras();
	    Observador cliente3 = new ClienteAdictoAlasCompras();

	    tienda.agregarSubscripcion(cliente1);
	    tienda.agregarSubscripcion(cliente2);
	    
	    tienda.notificarSubscripciones();
	
	    tienda.eliminarSubscripcion(cliente1);
	    tienda.agregarSubscripcion(cliente3);
	    
	    tienda.notificarSubscripciones();
	}
}
