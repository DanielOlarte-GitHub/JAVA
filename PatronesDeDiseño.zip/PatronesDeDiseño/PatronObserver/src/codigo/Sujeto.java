package codigo;

public interface Sujeto {
	public void agregarSubscripcion(Observador observer);
    public void eliminarSubscripcion(Observador observer);
    public void notificarSubscripciones();
}
