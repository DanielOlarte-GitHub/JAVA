package generos.comedia;

public class ComediaAmazonPrime implements IComedia{
    public String productora() {
        return "Soy una pelicula de comedia producida por Amazon prime";
    }
}
