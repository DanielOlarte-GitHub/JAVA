package generos.comedia;

public class ComediaNetflix implements IComedia{
    public String productora() {
        return "Soy una pelicula de comedia producida por Netflix";
    }
}
