package generos.comedia;

public interface IComedia {
    public String productora();
}
