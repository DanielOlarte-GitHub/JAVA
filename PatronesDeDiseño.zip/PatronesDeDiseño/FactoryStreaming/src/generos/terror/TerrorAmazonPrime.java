package generos.terror;

public class TerrorAmazonPrime implements ITerror{
   public String productora(){
       return "Soy una pelicula de terror producida por Amazon Prime";
   }
}
