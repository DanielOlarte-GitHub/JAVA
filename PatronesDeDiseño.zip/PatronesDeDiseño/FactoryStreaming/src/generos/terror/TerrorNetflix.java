package generos.terror;

public class TerrorNetflix implements ITerror{
    public String productora(){
        return "Soy una pelicula de terror producida por Netflix";
    }

}
