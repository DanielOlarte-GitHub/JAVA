package generos.terror;

public interface ITerror {
    public String productora();
}
