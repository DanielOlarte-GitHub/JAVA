package factory;

import generos.comedia.IComedia;
import generos.terror.ITerror;

public interface IFactoryEntretenimiento {
    public IComedia producirPeliculaComedia();
    public ITerror producirPeliculaTerror();
}
