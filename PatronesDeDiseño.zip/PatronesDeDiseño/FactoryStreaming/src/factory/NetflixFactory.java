package factory;

import generos.comedia.ComediaNetflix;
import generos.comedia.IComedia;
import generos.terror.ITerror;
import generos.terror.TerrorAmazonPrime;
import generos.terror.TerrorNetflix;

public class NetflixFactory implements IFactoryEntretenimiento{
    public IComedia producirPeliculaComedia(){
        return new ComediaNetflix();
    }

    public ITerror producirPeliculaTerror(){
        return new TerrorNetflix();
    }
}
