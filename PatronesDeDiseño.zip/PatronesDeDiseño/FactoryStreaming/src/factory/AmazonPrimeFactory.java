package factory;

import generos.comedia.ComediaAmazonPrime;
import generos.comedia.ComediaNetflix;
import generos.comedia.IComedia;
import generos.terror.ITerror;
import generos.terror.TerrorAmazonPrime;

public class AmazonPrimeFactory implements IFactoryEntretenimiento{


    public IComedia producirPeliculaComedia(){
        return new ComediaAmazonPrime();
    }


    public ITerror producirPeliculaTerror() {
    return new TerrorAmazonPrime();
    }
}
