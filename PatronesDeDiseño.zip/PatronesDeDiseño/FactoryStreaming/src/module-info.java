module FactoryStreaming {
}