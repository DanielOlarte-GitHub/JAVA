package launcher;

import factory.AmazonPrimeFactory;
import factory.IFactoryEntretenimiento;
import generos.comedia.IComedia;
import generos.terror.ITerror;

public class client {
    public static void main(String[] args) {
        IFactoryEntretenimiento factory = new AmazonPrimeFactory();
        ITerror terror = factory.producirPeliculaTerror();
        IComedia comedia = factory.producirPeliculaComedia();
        System.out.println(terror.productora());
        System.out.println(comedia.productora());
    }
}
