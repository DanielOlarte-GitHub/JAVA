module ProyectoFinalMAJS {
}