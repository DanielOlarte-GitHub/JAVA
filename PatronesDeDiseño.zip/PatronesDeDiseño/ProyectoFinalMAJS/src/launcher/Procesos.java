package launcher;

import java.util.ArrayList;
import java.util.Scanner;

import clases.Cache;
import clases.Canal;
import clases.CreadorContenido;
import clases.MAJS;
import clases.Queja;
import clases.Usuario;
import clases.Videos;
import interfaces.IObservador;
import interfaces.IProcesoVideo;

public class Procesos implements IProcesoVideo {
	
	static MAJS majs = new MAJS();
	static Scanner leer = new Scanner(System.in);
	static Cache cachesito = new Cache();
	
	public void crearCanalCreadorContenido() {
		String nombre, fecha, categoria;
		int suscriptores;
		ArrayList<Videos> Videos = new ArrayList<Videos>();
		ArrayList<Canal> canal = new ArrayList<Canal>();
		ArrayList<IObservador> Suscriptores = null;
		System.out.println("Digite el nombre del canal: ");
		nombre = leer.nextLine();
		System.out.println("Digite la fecha de creacion del canal: ");
		fecha = leer.nextLine();
		System.out.println("Digite la categoria del canal: ");
		categoria = leer.nextLine();
		suscriptores = 0;
		Canal canal1 = new Canal(nombre, fecha, categoria, suscriptores, Videos, Suscriptores);
		canal.add(canal1);
		crearCreador(canal);
	}
	
	public void crearCanalUsuario() {
		String nombre, fecha, categoria;
		int suscriptores;
		System.out.println("Digite el nombre del canal: ");
		nombre = leer.nextLine();
		System.out.println("Digite la fecha de creacion del canal: ");
		fecha = leer.nextLine();
		System.out.println("Digite la categoria del canal: ");
		categoria = leer.nextLine();
		suscriptores = 0;
		Canal canal1 = new Canal(nombre, fecha, categoria, suscriptores);
		crearUsuario(canal1);
	}
	
	public static void crearUsuario(Canal canal) {
	//	System.out.println("Se ha creado el usuario");
		String nombre, correoElectronico, contrasenia;
		System.out.println("Digite el nombre del usuario: ");
		nombre = leer.nextLine();
		System.out.println("Digite el correo electronico del usuario: ");
		correoElectronico = leer.nextLine();
		System.out.println("Digite la contrasenia del usuario: ");
		contrasenia = leer.nextLine();
		Usuario usu = new Usuario(nombre, nombre, correoElectronico, contrasenia);
	}
	
	//Cadena de responsabilidad
	public void crearQueja( ) {
	//	System.out.println("Se ha creado la queja");
		String asunto, descripcion, categoria, fechaQueja;
		System.out.println("Ingrese el asunto de su queja: ");
		asunto = leer.nextLine();
		System.out.println("Ingrese la descripcion de su queja: ");
		descripcion = leer.nextLine();
		System.out.println("Ingrese la categoria de su queja: ");
		categoria = leer.nextLine();
		System.out.println("Ingrese la fecha de su queja: ");
		fechaQueja = leer.nextLine();
		Queja queja = new Queja(asunto, descripcion, categoria, fechaQueja);
		enviarQueja(queja);
	}
	
	public static void enviarQueja(Queja quejita) {
		System.out.println("Se ha enviado la queja");
		majs.recibirQueja(quejita);
	}
	
	//Proxy - Observer
	public void crearVideos(Canal canal) {
	//	System.out.println("Se ha creado el video");
		String nombreVideo, fechaCreacionVideo, categoriaVideo;
		int reproducciones, cantidadLikes;
		System.out.println("Ingrese el nombre del video: ");
		nombreVideo = leer.nextLine();
		System.out.println("Ingrese la fecha de creacion del video: ");
		fechaCreacionVideo = leer.nextLine();
		System.out.println("Ingrese la categoria del video: ");
		categoriaVideo = leer.nextLine();
		System.out.println("Ingrese la cantidad de reproducciones que tiene el video: ");
		reproducciones = leer.nextInt();
		System.out.println("Ingrese la cantidad de likes que tiene el video: ");
		cantidadLikes = leer.nextInt();
		Videos video = new Videos(nombreVideo, fechaCreacionVideo, categoriaVideo, reproducciones, cantidadLikes);
		cachesito.subirVideo(video, canal); 
		
	}
	
	
	public static void crearCreador(ArrayList<Canal> canal) {
	//	System.out.println("Se ha creado el creador de contenido");
		String nombre, correoElectronico, contrasenia, fechaCanal;
		ArrayList<Canal> Canales = canal;
		System.out.println("Digite el nombre del creador: ");
		nombre = leer.nextLine();
		System.out.println("Digite el correo electronico del creador: ");
		correoElectronico = leer.nextLine();
		System.out.println("Digite la contrasenia del creador: ");
		contrasenia = leer.nextLine();
		System.out.println("Digite la fecha de creacion del canal: ");
		fechaCanal = leer.nextLine();
		CreadorContenido creador = new CreadorContenido(nombre, correoElectronico, contrasenia, fechaCanal,Canales);	
	}

	@Override
	public void subirVideo(Videos videito, Canal canal) {
		ArrayList<Videos> videitos;
		videitos = canal.getVideos();
		videitos.add(videito);
		canal.setVideos(videitos);
		Usuario usuarito = new Usuario();
		usuarito.actualizar();
	}
}

