package launcher;

import java.util.Scanner;

public class Cliente {

	static Scanner leer = new Scanner(System.in);
		
	public static void main(String[] args) {
		System.out.println("Bienvenido a MAJS!!!");
		menu();
	}

	public static void menu() {
		System.out.println("\n--- M E N U ---\n");
		System.out.println("\n1. Crear usuario  ");
		System.out.println("\n2. Crear creador de contenido");
		System.out.println("\n3. Crear video ");
		System.out.println("\n4. Crear Queja ");
		System.out.println("\n0. Salir ");
		System.out.print("\n\nIngrese una opcion:  ");

		int opc = leer.nextInt();

		Opciones opcioncitas = new Opciones();
		opcioncitas.opcioncitas(opc);
		menu();
	}

}
