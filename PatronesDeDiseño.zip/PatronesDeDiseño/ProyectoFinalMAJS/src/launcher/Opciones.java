package launcher;

import clases.Canal;

public class Opciones {

	static Procesos procesitos = new Procesos();
	
	public void opcioncitas(int opc) {

		
		switch (opc) {
		case 1:
			procesitos.crearCanalUsuario();
			System.out.println("Se ha creado el canal para usuario");
			break;

		case 2:
			procesitos.crearCanalCreadorContenido();	
			System.out.println("Se ha creado el canal para creador de contenido");
			break;

		case 3:
			Canal canalito = new Canal(""," "," ",0);
			procesitos.crearVideos(canalito);
			System.out.println("Se ha creado el video");
			
			break;

		case 4:
			System.out.println("Se ha creado la queja");
			procesitos.crearQueja();
			break;

		case 0:
			System.out.println("Bai");
			System.exit(0);
			break;
			
		default:
			System.out.println("Digito una opcion invalida, intentelo nuevamente");
			break;
		}
	}
}
