package interfaces;

public interface IObservable {
	
	public void agregar(IObservador o); 
	
	public void notificar();
	
	
}
