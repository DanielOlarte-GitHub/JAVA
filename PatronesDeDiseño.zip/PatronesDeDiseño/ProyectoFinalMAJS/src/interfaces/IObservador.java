package interfaces;

public interface IObservador {

	public void actualizar();
}
