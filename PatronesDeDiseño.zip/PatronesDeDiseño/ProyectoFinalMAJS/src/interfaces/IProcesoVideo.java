package interfaces;

import clases.Canal;
import clases.Videos;

public interface IProcesoVideo {

	public void subirVideo(Videos videito, Canal canalito);
	
}
