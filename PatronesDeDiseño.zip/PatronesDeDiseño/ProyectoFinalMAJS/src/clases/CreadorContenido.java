package clases;

import java.util.ArrayList;
import java.util.Iterator;

import interfaces.IObservador;

public class CreadorContenido {

	private String Nombre;
	private String CorreoElectronico;
	private String Contrasenia;
	private String FechaNacimiento;
	private ArrayList<Canal> Canales = new ArrayList<Canal> ();
	
	public CreadorContenido(String nombre, String correoElectronico, String contrasenia, String fechaNacimiento,
			ArrayList<Canal> canales) {
		super();
		Nombre = nombre;
		CorreoElectronico = correoElectronico;
		Contrasenia = contrasenia;
		FechaNacimiento = fechaNacimiento;
		Canales = canales;
	}

	public CreadorContenido() {
		// TODO Auto-generated constructor stub
	}
	
	public String getNombre() {
		return Nombre;
	}
	public void setNombre(String nombre) {
		Nombre = nombre;
	}
	public String getCorreoElectronico() {
		return CorreoElectronico;
	}
	public void setCorreoElectronico(String correoElectronico) {
		CorreoElectronico = correoElectronico;
	}
	public String getContrasenia() {
		return Contrasenia;
	}
	public void setContrasenia(String contrase�a) {
		Contrasenia = contrase�a;
	}
	public String getFechaNacimiento() {
		return FechaNacimiento;
	}
	public void setFechaNacimiento(String fechaNacimiento) {
		FechaNacimiento = fechaNacimiento;
	}
	
	public ArrayList<Canal> getCanales() {
		return Canales;
	}

	public void setCanales(ArrayList<Canal> canales) {
		Canales = canales;
	}

	public void recibirQueja(Queja quejita) {
		System.out.println("Se ha recibido la queja");
		resolverQueja();
	}
	
	public static void resolverQueja() {
		System.out.println("Se ha resuelto la queja");
	}
}
