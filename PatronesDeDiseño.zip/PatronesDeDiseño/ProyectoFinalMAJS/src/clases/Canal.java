package clases;

import java.util.ArrayList;
import java.util.Iterator;

import interfaces.IObservable;
import interfaces.IObservador;

public class Canal implements IObservable{

	private String NombreCanal;
	private String FechaCreacionCanal;
	private String CategoriaCanal;
	private int SuscriptoresCant;
	private ArrayList<Videos> Videos = new ArrayList<Videos> ();
	
	private ArrayList<IObservador> channelSubscribers = new ArrayList<IObservador> ();
	
	public void agregar(IObservador o) {
		this.channelSubscribers.add(o);
	}
	
	 public void notificar() {
	        Iterator<IObservador> var2 = this.channelSubscribers.iterator();
	        while(var2.hasNext()) {
	            IObservador channel = (IObservador)var2.next();
	            channel.actualizar();
	        }
	 }
	
	//Creador
	 public Canal(String nombreCanal, String fechaCreacionCanal, String categoriaCanal, int suscriptoresCant,
				ArrayList<clases.Videos> videos, ArrayList<IObservador> channelSubscribers) {
			super();
			NombreCanal = nombreCanal;
			FechaCreacionCanal = fechaCreacionCanal;
			CategoriaCanal = categoriaCanal;
			SuscriptoresCant = suscriptoresCant;
			Videos = videos;
			this.channelSubscribers = channelSubscribers;
		}

	//Usuario
	public Canal(String nombreCanal, String fechaCreacionCanal, String categoriaCanal, int suscriptoresCant) {
		super();
		NombreCanal = nombreCanal;
		FechaCreacionCanal = fechaCreacionCanal;
		CategoriaCanal = categoriaCanal;
		SuscriptoresCant = suscriptoresCant;
	}

	public String getNombreCanal() {
		return NombreCanal;
	}

	public void setNombreCanal(String nombreCanal) {
		NombreCanal = nombreCanal;
	}

	public String getFechaCreacionCanal() {
		return FechaCreacionCanal;
	}

	public void setFechaCreacionCanal(String fechaCreacionCanal) {
		FechaCreacionCanal = fechaCreacionCanal;
	}

	public String getCategoriaCanal() {
		return CategoriaCanal;
	}

	public void setCategoriaCanal(String categoriaCanal) {
		CategoriaCanal = categoriaCanal;
	}

	public int getSuscriptoresCant() {
		return SuscriptoresCant;
	}

	public void setSuscriptoresCant(int suscriptoresCant) {
		SuscriptoresCant = suscriptoresCant;
	}

	public ArrayList<Videos> getVideos() {
		return Videos;
	}

	public void setVideos(ArrayList<Videos> videos) {
		Videos = videos;
	}
	
	
}
