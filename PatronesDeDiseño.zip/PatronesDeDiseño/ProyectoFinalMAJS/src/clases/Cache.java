package clases;

import interfaces.IProcesoVideo;
import launcher.Procesos;

	public class Cache implements IProcesoVideo {

		private Procesos procesitos;
		
		@Override
		public void subirVideo(Videos videito, Canal canalito) {
			// TODO Auto-generated method stub
			if (procesitos == null) {
				procesitos = new Procesos();
			}
			procesitos.subirVideo(videito, canalito);
			
		}
		
		
	
}
