package clases;

public class MAJS {

	private CreadorContenido[] CreadoresContenido;
	private Queja[] Quejas;
	private Usuario[] Usuarios;

	public MAJS(CreadorContenido[] creadoresContenido, Queja[] quejas, Usuario[] usuarios) {
		super();
		CreadoresContenido = creadoresContenido;
		Quejas = quejas;
		Usuarios = usuarios;
	}
	
	public MAJS() {
		// TODO Auto-generated constructor stub
	}

	public CreadorContenido[] getCreadoresContenido() {
		return CreadoresContenido;
	}

	public void setCreadoresContenido(CreadorContenido[] creadoresContenido) {
		CreadoresContenido = creadoresContenido;
	}

	public Queja[] getQuejas() {
		return Quejas;
	}

	public void setQuejas(Queja[] quejas) {
		Quejas = quejas;
	}

	public Usuario[] getUsuarios() {
		return Usuarios;
	}

	public void setUsuarios(Usuario[] usuarios) {
		Usuarios = usuarios;
	}
	
	public void recibirQueja(Queja quejita) {
		System.out.println("Se ha recibido la queja");
		if(quejita.getCategoria() == "Creador contenido") {
			System.out.println("Se ha enviado la queja al creador de contenido");
			enviarQuejaCreadorContenido(quejita);
		}else {
			resolverQueja();
		}
	}
	
	public static void resolverQueja() {
		System.out.println("Se ha resuelto la queja");
	}
	
	public static void enviarQuejaCreadorContenido(Queja quejita) {
		CreadorContenido creadorcito = new CreadorContenido();
		creadorcito.recibirQueja(quejita);
	}

}
