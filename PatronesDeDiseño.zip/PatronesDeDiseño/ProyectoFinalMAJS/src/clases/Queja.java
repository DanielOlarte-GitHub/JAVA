package clases;

public class Queja {

	private String Asunto;
	private String Descripcion;
	private String Categoria;
	private String FechaQueja;
	
	public Queja(String asunto, String descripcion, String categoria, String fechaQueja) {
		super();
		Asunto = asunto;
		Descripcion = descripcion;
		Categoria = categoria;
		FechaQueja = fechaQueja;
	}
	
	public String getAsunto() {
		return Asunto;
	}
	public void setAsunto(String asunto) {
		Asunto = asunto;
	}
	public String getDescripcion() {
		return Descripcion;
	}
	public void setDescripcion(String descripcion) {
		Descripcion = descripcion;
	}
	public String getCategoria() {
		return Categoria;
	}
	public void setCategoria(String categoria) {
		Categoria = categoria;
	}
	public String getFechaQueja() {
		return FechaQueja;
	}
	public void setFechaQueja(String fechaQueja) {
		FechaQueja = fechaQueja;
	}
	
	
	
}
