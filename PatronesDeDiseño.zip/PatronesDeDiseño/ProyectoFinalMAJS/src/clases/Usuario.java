package clases;

import java.util.ArrayList;

import interfaces.IObservable;
import interfaces.IObservador;

public class Usuario implements IObservador {

	private String Nickname;
	private String Nombre;
	private String CorreoElectronico;
	private String Contrasenia;
	private ArrayList<Canal> Canales = new ArrayList<Canal> ();
	
	private IObservable observable = null;
	
	public Usuario(IObservable o) {
		super();
		this.observable = o;
	}

	public Usuario(String nickname, String nombre, String correoElectronico, String contrasenia) {
		super();
		Nickname = nickname;
		Nombre = nombre;
		CorreoElectronico = correoElectronico;
		Contrasenia = contrasenia;
	}
	
	public Usuario() {
		// TODO Auto-generated constructor stub
	}
	
	public String getNickname() {
		return Nickname;
	}
	public void setNickname(String nickname) {
		Nickname = nickname;
	}
	public String getNombre() {
		return Nombre;
	}
	public void setNombre(String nombre) {
		Nombre = nombre;
	}
	public String getCorreoElectronico() {
		return CorreoElectronico;
	}
	public void setCorreoElectronico(String correoElectronico) {
		CorreoElectronico = correoElectronico;
	}
	public String getContrasenia() {
		return Contrasenia;
	}
	public void setContrasenia(String contrasenia) {
		Contrasenia = contrasenia;
	}
	
	public ArrayList<Canal> getCanales() {
		return Canales;
	}

	public IObservable getObservable() {
		return observable;
	}

	public void setObservable(IObservable observable) {
		this.observable = observable;
	}

	public void setCanales(ArrayList<Canal> canales) {
		Canales = canales;
	}

	@Override
	public void actualizar() {
		// TODO Auto-generated method stub
		System.out.println("\nOBSERVER: El creador de contenido ha subido nuevo video\n");
	}



}
