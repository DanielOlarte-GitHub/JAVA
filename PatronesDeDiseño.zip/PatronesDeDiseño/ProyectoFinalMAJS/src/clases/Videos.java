package clases;

public class Videos {

	private String NombreVideo;
	private String FechaCreacionVideo;
	private String ClasificacionVideo;
	private int Reproducciones;
	private int CantidadLikes;
	
	public Videos(String nombreVideo, String fechaCreacionVideo, String categoriaVideo, int reproducciones,
			int cantidadLikes) {
		super();
		NombreVideo = nombreVideo;
		FechaCreacionVideo = fechaCreacionVideo;
		ClasificacionVideo = categoriaVideo;
		Reproducciones = reproducciones;
		CantidadLikes = cantidadLikes;
	}
	
	public String getNombreVideo() {
		return NombreVideo;
	}
	public void setNombreVideo(String nombreVideo) {
		NombreVideo = nombreVideo;
	}
	public String getFechaCreacionVideo() {
		return FechaCreacionVideo;
	}
	public void setFechaCreacionVideo(String fechaCreacionVideo) {
		FechaCreacionVideo = fechaCreacionVideo;
	}
	public String getCategoriaVideo() {
		return ClasificacionVideo;
	}
	public void setCategoriaVideo(String categoriaVideo) {
		ClasificacionVideo = categoriaVideo;
	}
	public int getReproducciones() {
		return Reproducciones;
	}
	public void setReproducciones(int reproducciones) {
		Reproducciones = reproducciones;
	}
	public int getCantidadLikes() {
		return CantidadLikes;
	}
	public void setCantidadLikes(int cantidadLikes) {
		CantidadLikes = cantidadLikes;
	}
	
	
	
	
}
