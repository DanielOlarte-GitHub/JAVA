package codigo;

public class Iphone implements TiendaCelulares {  
    @Override  
    public void modelo() {  
        System.out.println(" Iphone XI ");  
    }  
    @Override  
    public void precio() {  
    System.out.println(" COP 5000000.00 ");  
    }  
}  