package codigo;

public interface TiendaCelulares {
	public void modelo();  
    public void precio();  
}
