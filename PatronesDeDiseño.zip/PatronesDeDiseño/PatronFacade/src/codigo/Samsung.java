package codigo;

public class Samsung implements TiendaCelulares {  
    @Override  
    public void modelo() {  
    System.out.println(" Samsung galaxy A51 ");  
    }  
    
    @Override  
    public void precio() {  
        System.out.println(" COP 3000000.00 ");  
    }  
}  
