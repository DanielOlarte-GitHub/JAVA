package codigo;

public class Xiaomi implements TiendaCelulares {  
    @Override  
    public void modelo() {  
    System.out.println(" Xiaomi mi 9t Pro ");  
    }  
    @Override  
    public void precio() {  
        System.out.println(" COP 2000000.00 ");  
    }  
}  
