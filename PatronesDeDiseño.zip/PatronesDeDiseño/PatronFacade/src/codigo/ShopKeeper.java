package codigo;

public class ShopKeeper {  
    private TiendaCelulares iphone;  
    private TiendaCelulares samsung;  
    private TiendaCelulares Xiaomi;  
      
    public ShopKeeper(){  
        iphone= new Iphone();  
        samsung=new Samsung();  
        Xiaomi=new Xiaomi();  
    }  
    public void iphoneSale(){  
        iphone.modelo();  
        iphone.precio();  
    }  
        public void samsungSale(){  
        samsung.modelo();  
        samsung.precio();  
    }  
   public void blackberrySale(){  
    Xiaomi.modelo();  
    Xiaomi.precio();  
   }  
}  
