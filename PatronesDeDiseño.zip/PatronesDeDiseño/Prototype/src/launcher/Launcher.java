package launcher;

import model.Circle;
import model.Square;

public class Launcher {
    public static void main(String[]args){
        Circle c1 = new Circle();

        c1.setA(10);
        c1.setB(1);
        c1.setX(2);
        c1.setY(3);

        Circle c2=(Circle) c1.clone();

        c2.setX(4000);

        Circle c3 = (Circle) c2.clone();

        c3.setX(20);

        System.out.println(c1.getX());
        System.out.println(c2.getX());
        System.out.println(c3.getX());

        Square sq1= new Square();

        sq1.setA(65);
        sq1.setB(34);

        Square sq2=(Square) sq1.clone();
        System.out.println("stop!");
    }
}
