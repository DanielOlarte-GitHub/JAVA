package model;

public abstract class Shape {
    private int a;
    private int b;

    public Shape(){}

    protected Shape(Shape s){
        this.a=s.a;
        this.b=s.b;
    }

    public int getA() {
        return a;
    }

    public void setA(int a) {
        this.a = a;
    }

    public int getB() {
        return b;
    }

    public void setB(int b) {
        this.b = b;
    }

    public abstract Shape clone();
}
