package model;

public class Square extends Shape{

    public Square(){}

    private Square(Square s){
        super(s);
    }

    @Override
    public Shape clone() {
        return new Square(this);
    }
}
