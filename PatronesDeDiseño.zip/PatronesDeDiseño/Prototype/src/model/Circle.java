package model;

public class Circle extends Shape{

    private int x;
    private int y;

    public Circle(){}
    
    private Circle(Circle c){
        super(c);
        this.x=c.x;
        this.y=c.y;
    }

    @Override
    public Shape clone() {
        return new Circle(this);
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }
}
