package archivos;
public interface Observer {
    public void actualizar(String mensaje);
}
