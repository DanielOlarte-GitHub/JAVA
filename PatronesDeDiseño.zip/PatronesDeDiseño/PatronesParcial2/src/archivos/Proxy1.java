package archivos;
import java.io.IOException;

public interface Proxy1 {
    
    public void ArchivoModificado() throws IOException;
    
    
}