package archivos;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.Scanner;


public interface Facade {
    
    public void crear();
    public void Leer();
    public void guardarArchivo(String memoria);
    public void cargarMemoria();
    public Scanner modoLectura();
    public BufferedWriter modoEscritura();
    
}
