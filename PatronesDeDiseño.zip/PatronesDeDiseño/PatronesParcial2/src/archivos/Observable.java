package archivos;
public interface Observable {
public void anadir(Observer o);
public void eliminar(Observer o);
public void notificar();
}
