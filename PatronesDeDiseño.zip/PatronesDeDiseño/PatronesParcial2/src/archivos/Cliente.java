package archivos;

import java.util.Scanner;

public class Cliente {
	
	static Scanner leer = new Scanner(System.in);
	
	public static void menu() {
		Facade1 fac = new Facade1();
        App miApp = new App();
        Notificador miNoti = new Notificador(miApp);
        miApp.anadir(miNoti);
        
		System.out.print("\nDIGITE LA OPCION QUE DESEE:\n1) Crear Archivo\n2) Modificar\n3) Leer\n0) Salir\nDigite Su Opcion: ");
        int men = leer.nextInt();
        
        switch(men) {
        	case 1:
        		fac.crear();
        	break;
        	
        	case 2:
        		miApp.ArchivoModificado();
            break;
            	
        	case 3:
        		fac.Leer();
            break;	
        	
        	case 0:
        		System.out.println("\n\n\nGRACIAS POR USAR EL PROGRAMA\n\n");
        		System.exit(0);
            break;
            
            default:
            	System.out.println("\nDigito un valor Invalido, intente de nuevo");
            break;	
        }
        menu();
	}

    public static void main(String[] args) {
        System.out.println("\nBIENVENIDO AL CREADOR,EDITOR Y LECTOR DE ARCHIVOS");
        menu();
    }
    
    

}
