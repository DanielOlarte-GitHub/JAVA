package archivos;
public class Notificador implements Observer {

    private Observable observable = null;

    public Notificador(Observable observable) {
        this.observable=observable;
    }
    
    @Override
    
    public void actualizar(String mensaje) {
        System.out.println("\n\n####OBSERVER DICE: actualizado\n\n");       
    }
    
}
