package products.debitoCorriente;

import builderPattern.IBuilderProductoDebito;

public interface IBuilderDebitoCorriente extends IBuilderProductoDebito{
	
}
//