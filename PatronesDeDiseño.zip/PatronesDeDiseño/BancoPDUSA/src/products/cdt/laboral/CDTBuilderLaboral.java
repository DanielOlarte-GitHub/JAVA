package products.cdt.laboral;
import java.util.HashMap;

import products.cdt.IBuilderCDT;

public class CDTBuilderLaboral implements IBuilderCDT{
	
	private HashMap<String, String> datosPersonales = new HashMap<String, String>();
	private CDTLaboral cdt;
	
	public void reset() {
		cdt = new CDTLaboral();
	}//

	@Override
	public void putDatosPersonalesTitular(String nombre, String id, String fechaNacimiento) {
		datosPersonales.put("nombre", nombre);
		datosPersonales.put("id", id);
		datosPersonales.put("fechaN", fechaNacimiento);
		cdt.setDatosPersonales(datosPersonales);
		
	}

	@Override
	public void retirar() {
		
		System.out.println("Se ha retirado el dinero!");
		
	}

	@Override
	public void consultar() {
		System.out.println("Se ha hecho la consulta con exito");
		
	}

	@Override
	public void putBaseMonto(double monto) {
		cdt.setBaseMonto(monto);
		
	}

	@Override
	public void putBaseTiempo(double tiempo) {
		cdt.setBaseTiempo(tiempo);
		
	}
	@Override
	public void putIntereses(double interes) {
		cdt.setIntereses(interes);
		
	}
	@Override
	public void putNivelRiesgo(double nivelR) {
		cdt.setNivelDeRiesgo(nivelR);
		
	}
	
	public CDTLaboral getProduct() {
		return this.cdt;
	}
	
}
