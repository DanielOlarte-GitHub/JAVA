package products.cdt.mayores18;

import java.util.HashMap;

import products.cdt.*;
//BUILDER PARA 4 PRODUCTORS
//FACTORY PARA MENU
public class CDTBuilderMayores18 implements IBuilderCDT{
	private HashMap<String, String> datosPersonales = new HashMap<String, String>();
	private CDTmayores18 cdt;

	public void reset() {
		cdt = new CDTmayores18();
	}
	//

	@Override
	public void putDatosPersonalesTitular(String nombre, String id, String fechaNacimiento) {
		datosPersonales.put("nombre", nombre);
		datosPersonales.put("id", id);
		datosPersonales.put("fechaN", fechaNacimiento);
		cdt.setDatosPersonales(datosPersonales);
		
	}

	@Override
	public void retirar() {
		
		System.out.println("Se ha retirado el dinero!");
		
	}

	@Override
	public void consultar() {
		System.out.println("Se ha hecho la consulta con exito");
		
	}

	@Override
	public void putBaseMonto(double monto) {
		cdt.setBaseMonto(monto);
		
	}

	@Override
	public void putBaseTiempo(double tiempo) {
		cdt.setBaseTiempo(tiempo);
		
	}
	@Override
	public void putIntereses(double interes) {
		cdt.setIntereses(interes);
		
	}
	@Override
	public void putNivelRiesgo(double nivelR) {
		cdt.setNivelDeRiesgo(nivelR);
		
	}
	
	public CDTmayores18 getProduct() {
		return this.cdt;
	}
	
}
