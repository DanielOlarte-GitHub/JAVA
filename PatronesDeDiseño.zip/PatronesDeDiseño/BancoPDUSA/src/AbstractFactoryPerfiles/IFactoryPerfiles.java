package AbstractFactoryPerfiles;

public interface IFactoryPerfiles {
	//
}
