package builderPattern;

import products.credito.IBuilderCredito;

public interface IBuilderTarjetaCredito extends IBuilderCredito{
	//Interfaz Tarjeta Credito
	public void crearTarjeta();
}//
