package builderPattern;

public interface IBuilderProductoCredito extends IBuilderCuenta{
	//Interfaz Productos Credito (TC, CR)
	public void putCupo(int cupo);
	public void putCuotas(int cuotas);
	 	
	//
}
