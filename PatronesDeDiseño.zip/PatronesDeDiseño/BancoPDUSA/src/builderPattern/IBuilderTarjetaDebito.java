package builderPattern;

public interface IBuilderTarjetaDebito extends IBuilderProductoDebito{
	//Interfaz Tarjeta Debito
	public void crearTarjeta();
}
//