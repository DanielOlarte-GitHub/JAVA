package launcher;

import products.cdt.laboral.CDTLaboral;

public class Client {
	public static void main(String[]args) {
		Director d = new Director();
		CDTLaboral cdtL = d.cdtLaboral();
		System.out.println("los datos del CDT del Usuario es: ");
		//ENCRIPTADO System.out.println(cdtL.toString());
		cdtL.imprimirDatos();
		
		//
	}
}
