package launcher;

import products.cdt.laboral.CDTBuilderLaboral;
import products.cdt.laboral.CDTLaboral;

public class Director {
	
	public CDTLaboral cdtLaboral() {
		CDTBuilderLaboral CDTBL = new CDTBuilderLaboral();
		CDTBL.reset();
		
		CDTBL.putDatosPersonalesTitular("Shelsy Maria", "6", "100298");
		return CDTBL.getProduct();
	}
}//
