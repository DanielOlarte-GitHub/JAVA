package notas;

public class Estudiante {
	//Atributos
	private String notas[][];
	private String nombre;
	private String id;
	
	/**
	 * Constructor al crear un objeto
	 * @param Notas Matriz con notas y promedios
	 * @param nombre Nombre del estudiante
	 * @param id id del estudiante
	 */
	public Estudiante(String[][] Notas, String nombre, String id) {
		this.notas = Notas;
		this.nombre = nombre;
		this.id = id;
	}
	
	/**
	 * Constructor vacio para crear un objeto de esta clase sin pasar parametros
	 */
	public Estudiante() {
	}
	
	/**
	 * Metodo para mostrar Notas
	 */
	public void mostrarNotas() {
		for(int i =0; i<notas.length; i++) {
			for(int j=0; j<notas[0].length; j++) {
				System.out.print(notas[i][j]);
			}
			System.out.println("");
		}
	}

	/*
	 * GET
	 */
	@Override
	public String toString() {
		return "Nombre=" + nombre + ", Id=" + id ;
	}
	
	
}
