package quintoEjercicio;

import java.util.Scanner;

public class Palindromo {
	public static void palindromo(String cadena) {
		System.out.println("\n\nCOMPROBAR SI ES PALINDROMO\n");
		cadena = cadena.toLowerCase().replace(" ", "").replace(".", "").replace(",", "");
		String invertida = new StringBuilder(cadena).reverse().toString();
		if (invertida.equals(cadena)) {
			System.out.println("ES PALINDROMO");
		} else {
			System.out.println("NO ES PALINDROMO");
		}
	}

	public static void main(String[] args) {
		Scanner leer = new Scanner(System.in);
		String cadena;
		System.out.println("Digite la palabra o frase que quiera comprobar si es palindromo o no");
		cadena = leer.nextLine();
		palindromo(cadena);
		System.out.println("\n\nGRACIAS POR USAR EL PROGRAMA.");
	}
}
