package segundoEjercicio;

import java.util.Scanner;

public class Ordenado {
	static Scanner leer = new Scanner(System.in);
	static int arreglo[];
	
	public static void ordenDesorden(int tam) {
		boolean pasa = false;
		System.out.println("\nORDEN O DESORDEN?\n");
		for(int i=0; i<tam-1; i++) {
			if(arreglo[i] > arreglo[i+1]) {
				pasa = true;
				System.out.println("EL ARREGLO ESTA EN DESORDEN");
				break;
			}
		}
		
		if(pasa == false) {
			System.out.println("EL ARREGLO ESTA ORDENADO");
		}
	}
	
	public static void mostrarArreglo(int tam) {
		System.out.println("\nMOSTRANDO ARREGLO\n");
		System.out.print("ARREGLO: ");
		for(int i=0; i<tam; i++) {
			System.out.print(arreglo[i]+"  ");
		}
	}
	
	public static void llenarArreglo(int tam) {
		System.out.println("\nLLENANDO EL ARREGLO\n");
		int num;
		for(int i=0; i<tam; i++) {
			System.out.println("Digite el numero que desee que este en la posicion ["+i+"]");
			arreglo[i] = leer.nextInt();
		}
	}
	
	public static void main(String[] args) {
		int tam=0;
		
		System.out.println("Digite el tama�o que desee que tenga el arreglo");
		tam = leer.nextInt();
		arreglo = new int[tam];
		
		llenarArreglo(tam);
		mostrarArreglo(tam);
		ordenDesorden(tam);
		System.out.println("\n\nGracias por usar el programa");
	}
}
