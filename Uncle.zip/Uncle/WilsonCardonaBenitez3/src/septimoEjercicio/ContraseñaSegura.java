package septimoEjercicio;

import java.util.Scanner;

public class Contrase�aSegura {
	static String numero = "0123456789";
	static String mayuscula = "ABCDEFGHIJKLMN�OPQRSTUVWXYZ";
	static String minuscula = "abcdefghijklmn�opqrstuvwxyz";
	static String caracteres = "#$%&/()=?�-.,�+�{[]!";

	public static void palindromo(String contrase�a) {
		System.out.println("\n\nCOMPROBAR SEGURIDAD DE LA CONTRASE�A\n");
		boolean pasa = false, pasa2 = false, pasa3 = false, pasa4=false;
		if (contrase�a.length() >= 10) {

			for (int i = 0; i < contrase�a.length(); i++) {
				for(int j =0; j<numero.length(); j++){
					if(contrase�a.charAt(i) == numero.charAt(j)) {
						pasa = true;
						break;
					}
				}
				
				for(int j =0; j<minuscula.length(); j++){
					if(contrase�a.charAt(i) == minuscula.charAt(j)) {
						pasa2 = true;
						break;
					}
				}
				
				
				for(int j =0; j<mayuscula.length(); j++){
					if(contrase�a.charAt(i) == mayuscula.charAt(j)) {
						pasa3 = true;
						break;
					}
				}
				
				
				for(int j =0; j<caracteres.length(); j++){
					if(contrase�a.charAt(i) == caracteres.charAt(j)) {
						pasa4 = true;
						break;
					}
				}
			}
			
			if(!pasa) {
				System.out.println("SU CONTRASE�A NO ES SEGURA, NO CONTIENE NI UN NUMERO");
			}else if(!pasa2) {
				System.out.println("SU CONTRASE�A NO ES SEGURA, NO CONTIENE NI UN LETRA MINUSCULA");
			}else if(!pasa3) {
				System.out.println("SU CONTRASE�A NO ES SEGURA, NO CONTIENE NI UN LETRA MAYUSCULA");
			}else if(!pasa4) {
				System.out.println("SU CONTRASE�A NO ES SEGURA, NO CONTIENE NI UN SIMBOLO DIFERENTE A LETRAS Y NUMEROS");
			}
			
			if(pasa && pasa2 && pasa3 && pasa4) {
				System.out.println("SU CONTRASE�A SI ES SEGURA");
			}
			
		} else {
			System.out.println("SU CONTRASE�A NO ES SEGURA, ES MENOR A 10 CARACTERES");
		}
	}

	public static void main(String[] args) {

		Scanner leer = new Scanner(System.in);
		String contrase�a;
		System.out.println("Digite la contrase�a que quiera comprobar si segura");
		contrase�a = leer.nextLine();
		palindromo(contrase�a);
		System.out.println("\n\nGRACIAS POR USAR EL PROGRAMA.");
	}
}
