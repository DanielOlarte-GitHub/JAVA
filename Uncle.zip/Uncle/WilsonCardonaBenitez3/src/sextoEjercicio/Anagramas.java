package sextoEjercicio;

import java.util.Scanner;

public class Anagramas {
	public static void anagrama(String cadena, String cadena2) {
		System.out.println("\n\nCOMPROBAR SI ES UN ANAGRAMA\n");
		boolean pasa=false;
		if (cadena.length() == cadena2.length()) {
			for (int i = 0; i < cadena.length(); i++) {
				for(int j = 0; j < cadena2.length(); j++) {
					if(cadena2.charAt(i)==cadena.charAt(j)) {
						pasa = true;
						break;
					}
				}
				
				if(pasa == false) {
					System.out.println("No es un anagrama");
					return;
				}
				pasa = false;
			}
			System.out.println("Si es un anagrama");
		} else {
			System.out.println("No es un anagrama");
		}
	}

	public static void main(String[] args) {
		Scanner leer = new Scanner(System.in);
		String cadena, cadena2;
		System.out.println("Digite la palabra #1");
		cadena = leer.nextLine();
		System.out.println("Digite la palabra #2");
		cadena2 = leer.nextLine();
		anagrama(cadena, cadena2);
		System.out.println("\n\nGRACIAS POR USAR EL PROGRAMA.");
	}
}
