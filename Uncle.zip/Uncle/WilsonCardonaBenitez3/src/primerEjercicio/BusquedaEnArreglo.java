package primerEjercicio;

import java.util.Scanner;

public class BusquedaEnArreglo {
	static Scanner leer = new Scanner(System.in);
	static int arreglo[];
	
	public static void encontrarPosicion(int tam) {
		System.out.println("\n\nMOSTRAR LA POSICION DEL NUMERO DESEADO");
		int numeroEncontrar;
		System.out.println("\nDigite el numero que desea encontar la posicion");
		numeroEncontrar = leer.nextInt();
		System.out.println("\n");
		for(int i=0; i<tam; i++) {
			if(arreglo[i] == numeroEncontrar) {
				System.out.println("El numero "+ numeroEncontrar + " se encuentra en la posicion: "+(i+1) +" (Posicionamiento Normal)");
			}
		}
	}
	
	public static void mostrarArreglo(int tam) {
		System.out.println("\n\nMOSTRANDO ARREGLO\n");
		System.out.print("ARREGLO: ");
		for(int i=0; i<tam; i++) {
			System.out.print(arreglo[i]+"  ");
		}
	}
	
	public static void llenarArreglo(int tam) {
		System.out.println("\n\nLLENANDO EL ARREGLO\n");
		int num;
		for(int i=0; i<tam; i++) {
			System.out.println("Digite el numero que desee que este en la posicion ["+i+"]");
			arreglo[i] = leer.nextInt();
		}
	}
	
	public static void main(String[] args) {
		int tam=0;
		
		System.out.println("Digite el tama�o que desee que tenga el arreglo");
		tam = leer.nextInt();
		arreglo = new int[tam];
		
		llenarArreglo(tam);
		mostrarArreglo(tam);		
		encontrarPosicion(tam);
		System.out.println("\n\nGracias por usar el programa");
	}
}
