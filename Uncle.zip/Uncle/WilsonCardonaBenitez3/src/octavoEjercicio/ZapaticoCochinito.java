package octavoEjercicio;

import java.util.Scanner;

public class ZapaticoCochinito {
	static Scanner leer = new Scanner(System.in);
	static String personajes[];

	public static void jugar(int saltos, int cantJugadores) {
		int aux = 0, eliminado = cantJugadores;
		int turno = 0;
		do {
			if (aux == cantJugadores) {
				aux = 0;
			}

			if (personajes[aux] == "") {
				aux++;
			} else {
				if (turno == saltos) {
					System.out.println("Jugador " + personajes[aux] + " eliminado");
					personajes[aux] = "";
					eliminado--;
					aux++;
					turno = 0;
				} else {
					aux++;
					turno++;
				}
			}

		} while (eliminado > 1);
	}

	public static void mostrarJugadores() {
		System.out.println("\n\nMOSTRANDO JUGADORES\n");
		for (int i = 0; i < personajes.length; i++) {
			System.out.println(personajes[i]);
		}
	}

	public static void llenarJugadores(int cantPersonas) {
		System.out.println("\n\nLLENANDO JUGADORES\n");
		personajes = new String[cantPersonas];
		for (int i = 0; i < cantPersonas; i++) {
			System.out.println("Digite el nombre del jugador en la posicion " + i);
			personajes[i] = leer.next();
		}
	}

	public static void main(String[] args) {
		System.out.println("Digite cuantas personas desea que jueguen");
		int cantJugadores = leer.nextInt();

		llenarJugadores(cantJugadores);
		mostrarJugadores();

		System.out.println("\nDigite el numero K para saber de cuanto va a ser el conteo en la partida");
		int saltos = leer.nextInt();
		jugar(saltos, cantJugadores);
	}
}
