package cuartoEjercicio;

import java.util.Scanner;

public class Dardos {
	public static int dardos_puntaje(double numX, double numY) {
		if(numX<=1 && numX>=-1) {
			if(numY<=1 && numY>=-1) {
				return 15;
			}else if(numY<=2 && numY>=-2) {
				return 9;
			}else if(numY<=3 && numY>=-3) {
				return 5;
			}else if(numY<=4 && numY>=-4) {
				return 2;
			}else{
				return 1;
			}
				
		}else if(numX<=2 && numX>=-2) {
			if(numY<=2 && numY>=-2) {
				return 9;
			}else if(numY<=3 && numY>=-3) {
				return 5;
			}else if(numY<=4 && numY>=-4) {
				return 2;
			}else{
				return 1;
			}	
		}else if(numX<=3 && numX>=-3) {
			if(numY<=3 && numY>=-3) {
				return 5;
			}else if(numY<=4 && numY>=-4) {
				return 2;
			}else{
				return 1;
			}	
		}else if(numX<=4 && numX>=-4) {
			if(numY<=4 && numY>=-4) {
				return 2;
			}else{
				return 1;
			}	
		}else{
			return 1;	
		}
	}
	
	public static void main(String[]args) {
		Scanner leer = new Scanner(System.in);
		double numX=0, numY=0;
		int puntaje=0;
		System.out.println("\nJUEGO DE DARDOS:\n\n\n");
		do {
			System.out.println("Digite la coordenada X de su lanzamiento: (Valor Minimo: -5) (Valor Maximo: 5)");
			numX = leer.nextDouble();
			System.out.println("Digite la coordenada Y de su lanzamiento: (Valor Minimo: -5) (Valor Maximo: 5)");
			numY = leer.nextDouble();
			
			if(numX>5 || numX<-5 || numY>5 || numY<-5) {
				System.out.println("\nDIGITO UN VALOR INVALIDO INTENTE DE NUEVO..\n\n\n");
				numX = 0;
			}else {
				puntaje += dardos_puntaje(numX, numY);
				System.out.println("Su puntaje actual es: "+puntaje);
				System.out.println("\n\nSi desea terminar el juego digito 0\nSi quiere hacer otro lanzamiento digite cualquier otro numero");
				numX = leer.nextDouble();
				System.out.println("\n\n\n");
			}
		}while(numX!=0);
		System.out.println("SU PUNTUACION FINAL FUE: "+puntaje);
		System.out.println("PROGRAMA CERRADO..");
		System.exit(0);
	}
}
