package segundoEjercicio;

import java.util.Scanner;

public class ParImpar {
	public static String par_Impar(int num) {
		if(num%2==0) {
			return "Par";
		}else {
			return "Impar";
		}
	}
	
	public static void main(String[]args) {
		Scanner leer = new Scanner(System.in);
		int num=0;
		System.out.println("\nPAR O IMPAR:\n\n\n");
		do {
			System.out.println("Digite el numero que quiere saber si es Par o Impar: ");
			num = leer.nextInt();
			
			System.out.println("El numero "+num+" es: "+par_Impar(num));
			System.out.println("\n\nSi desea salir del programa digite 0\nSi quiere seguir digite cualquier otro numero");
			num = leer.nextInt();
			System.out.println("\n\n\n");
		}while(num!=0);
		System.out.println("PROGRAMA CERRADO..");
		System.exit(0);
	}
}
