package octavoEjercicio;

import java.util.Scanner;

public class Goldbash {
	// Todo num PAR suma de 2 primos
	// num IMPAR suma de 3 primos
	public static boolean primo(long num) {
		if (num == 0 || num == 1 || num == 4) {
			return false;
		}
		for (int x = 2; x < num / 2; x++) {
			if (num % x == 0)
				return false;
		}
		return true;
	}

	public static void main(String[] args) {
		Scanner leer = new Scanner(System.in);
		int salir = 0;
		System.out.println("\nCONJETURA DE GOLDBASH:\n\n\n");

		do {
			System.out.println("Conjetura de Goldbach. Ingrese numeros mayores que 5");

			long num = leer.nextLong();
			if (num == 0) {
				break;
			}
			if (num < 4 || num == 5) {
				continue;
			}

			if (num % 2 == 0) {
				for (long i = 2; i < num; i++) {
					if (!primo(i)) {
						continue;
					}
					for (long j = i; j < num; j++) {
						if (i + j == num && primo(j)) {
							System.out.printf("%,d = %,d + %,d\n", num, i, j);
						}
					}
				}
			} else {
				for (long i = 2; i < num; i++) {
					if (!primo(i)) {
						continue;
					}
					for (long j = i; j < num; j++) {
						if (!primo(j)) {
							continue;
						}
						for (long k = j; k < num; k++) {
							if (i + j + k == num && primo(k)) {
								System.out.printf("%,d = %,d + %,d + %,d\n", num, i, j, k);
							}
						}
					}
				}
			}
			System.out
					.println("\n\nSi desea salir del programa digite 0\nSi quiere seguir digite cualquier otro numero");
			salir = leer.nextInt();
			System.out.println("\n\n\n");
		} while (salir != 0);
		System.out.println("PROGRAMA CERRADO..");
		System.exit(0);
	}
}
