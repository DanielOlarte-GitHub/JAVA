package septimoEjercicio;

import java.util.Scanner;

public class Primalidad {
	
	public static String primo(int numero) {
		  if (numero == 0 || numero == 1 || numero == 4) {
		    return " NO ES PRIMO";
		  }
		  for (int i = 2; i < numero/2; i++) {
		    
		    if (numero % i == 0)
		      return " NO ES PRIMO";
		  }
		  return " ES PRIMO";
	}
	
	public static void main(String[]args) {
		Scanner leer = new Scanner(System.in);
		int num=0;
		System.out.println("\nNUMERO PRIMO O NO:\n\n\n");
		do {
			System.out.println("Digite el numero que quiere saber si es un numero primo: ");
			num = leer.nextInt();
			
			System.out.println("El numero "+num+primo(num));
			System.out.println("\n\nSi desea salir del programa digite 0\nSi quiere seguir digite cualquier otro numero");
			num = leer.nextInt();
			System.out.println("\n\n\n");
		}while(num!=0);
		System.out.println("PROGRAMA CERRADO..");
		System.exit(0);
	}
}
