package primerEjercicio;

import java.util.Scanner;

public class ValorAbsoluto {
	
	public static double valorAbsoluto(double num) {
		if(num<0) {
			return num*-1;
		}else {
			return num;
		}
	}
	
	public static void main(String[]args) {
		Scanner leer = new Scanner(System.in);
		double num=0;
		System.out.println("\nVALOR ABSOLUTO:\n\n\n");
		do {
			System.out.println("Digite el numero que quiere convertirlo con valor absoluto: ");
			num = leer.nextDouble();
			
			System.out.println("El valor absoluto de "+num+" es: "+valorAbsoluto(num));
			System.out.println("\n\nSi desea salir del programa digite 0\nSi quiere seguir digite cualquier otro numero");
			num = leer.nextDouble();
			System.out.println("\n\n\n");
		}while(num!=0);
		System.out.println("PROGRAMA CERRADO..");
		System.exit(0);
	}
}
