package quintoEjercicio;

import java.util.Scanner;

public class DistanciaBorde {
	public static void borde(double esqSupDerX, double esqSupDerY, double posicionX, double posicionY) {
		double bordeCercano=10000;
		if((esqSupDerX-posicionX)<bordeCercano){
			bordeCercano = (esqSupDerX-posicionX);
		}
		
		if((esqSupDerY-posicionY)<bordeCercano){
			bordeCercano = (esqSupDerY-posicionY);
		}
		
		if((posicionX-0)<bordeCercano){
			bordeCercano = (posicionX-0);
		}
		
		if((posicionY-0)<bordeCercano){
			bordeCercano = (posicionY-0);
		}
		System.out.println("LA MENOR DISTANCIA POR RECORRER PARA LLEGAR AL BORDE ES: "+bordeCercano);
	}
	
	public static void main(String[]args) {
		Scanner leer = new Scanner(System.in);
		double posicionX = 0, posicionY = 0, esqSupDerX=0, esqSupDerY=0;
		System.out.println("\nDISTANCIA BORDE:\n\n");
		
		do {
			System.out.println("Digite la coordenada X de la esquina superior derecha  (Mayor a 0)");
			esqSupDerX = leer.nextDouble();
			System.out.println("Digite la coordenada Y de la esquina superior derecha  (Mayor a 0)");
			esqSupDerY = leer.nextDouble();
			
			if(esqSupDerX <=0 || esqSupDerY<=0) {
				System.out.println("\nDIGITO UN VALOR INVALIDO INTENTE DE NUEVO..\n\n");
				esqSupDerX = -100001;
			}
		}while(esqSupDerX == -100001);
		
		
		do {
			System.out.println("\n\n\nDigite la coordenada X de su posicion");
			posicionX = leer.nextDouble();
			System.out.println("Digite la coordenada Y de su posicion");
			posicionY = leer.nextDouble();
			
			if(posicionX>=esqSupDerX || posicionX<=0 || posicionY>=esqSupDerY || posicionY<=0) {
				System.out.println("\nDIGITO UN VALOR FUERA DEL RECTANGULO INTENTE DE NUEVO ..\n\n\n");
				posicionX = 0;
			}else {
				borde(esqSupDerX, esqSupDerY, posicionX, posicionY);
				System.out.println("\n\nSi desea terminar el programa digite 0\nSi quiere probar con otra posicion digite cualquier otro numero");
				posicionX = leer.nextDouble();
				System.out.println("\n\n\n");
			}
		}while(posicionX!=0);
		System.out.println("PROGRAMA CERRADO..");
		System.exit(0);
	}
}
