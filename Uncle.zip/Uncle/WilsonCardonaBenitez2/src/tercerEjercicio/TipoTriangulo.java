package tercerEjercicio;

import java.util.Scanner;

public class TipoTriangulo {
	public static String tipo_Triangulo(double lado, double lado2, double lado3) {
		if(lado == lado2 && lado == lado3) {
			return "Triangulo Equilatero";
		}else if(lado != lado2 && lado != lado3 && lado2 != lado3){
			return "Triangulo Escaleno";
		}else {
			return "Triangulo Isoceles";
		}
	}
	
	public static void main(String[]args) {
		Scanner leer = new Scanner(System.in);
		double lado=0, lado2=0, lado3=0;
		System.out.println("\nTIPO DE TRIANGULO:\n\n\n");
		do {
			System.out.println("Digite el primer lado del triangulo: ");
			lado = leer.nextDouble();
			System.out.println("Digite el segundo lado del triangulo: ");
			lado2 = leer.nextDouble();
			System.out.println("Digite el tercer lado del triangulo: ");
			lado3 = leer.nextDouble();
			
			System.out.println("El triangulo con las medidas\nLado 1: "+lado+"\nLado 2: "+lado2+"\nLado 3: "+lado3+"\nEs un: "+tipo_Triangulo(lado,lado2,lado3));
			System.out.println("\n\nSi desea salir del programa digite 0\nSi quiere seguir digite cualquier otro numero");
			lado = leer.nextDouble();
			System.out.println("\n\n\n");
			
		}while(lado!=0);
		System.out.println("PROGRAMA CERRADO..");
		System.exit(0);
	}
}
