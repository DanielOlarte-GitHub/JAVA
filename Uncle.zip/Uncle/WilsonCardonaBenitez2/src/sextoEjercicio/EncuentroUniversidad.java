package sextoEjercicio;

import java.util.Scanner;

public class EncuentroUniversidad {
	
	public static void encuentro(int Ana, int Bernardo, int Carlos) {
		boolean bandera = true;
		int AnaH[] = new int[30], BernardoH[] = new int[30], CarlosH[] = new int[30];
		int contador = 2, auxK=0, auxJ=0, auxI=0;
		
		for(int i=0; i<30; i++) {
			AnaH[i] = Ana*i;
			BernardoH[i] = Bernardo*i;
			CarlosH[i] = Carlos*i;
		}
		
		for(int i=1; i<30;i++) {
			for(int j=1; j<30; j++) {
				if(AnaH[i] == BernardoH[j]) {
					for(int k=1; k<30; k++) {
						if(AnaH[i] == CarlosH[k]) {
							bandera =false;
							auxK = k;
							break;
						}
					}
					if(bandera == false) {
						auxJ=j;
						break;
					}
				}
			}
			if(bandera == false) {
				auxI=i;
				break;
			}
			
		}
		
		if(auxI > auxJ && auxI>auxK) {
			System.out.println("Ana Bernardo y Carlos se volveran a encontrar en: "+auxI);
		}else if(auxJ > auxI && auxJ>auxK) {
			System.out.println("Ana Bernardo y Carlos se volveran a encontrar en: "+auxJ);
		}else {
			System.out.println("Ana Bernardo y Carlos se volveran a encontrar en: "+auxK);
		}

		
	}
	
	public static void main(String[]args) {
		Scanner leer = new Scanner(System.in);
		int Ana=0, Bernardo=0, Carlos=0;
		System.out.println("\nENCUENTRO UNIVERSIDAD:\n\n\n");
		do {
			System.out.println("Digite Ana cada cuantos dias va a la Universidad: ");
			Ana = leer.nextInt();
			System.out.println("Digite Bernardo cada cuantos dias va a la Universidad: ");
			Bernardo = leer.nextInt();
			System.out.println("Digite Carlos cada cuantos dias va a la Universidad: ");
			Carlos = leer.nextInt();
			
			encuentro(Ana,Bernardo,Carlos);
			System.out.println("\n\nSi desea salir del programa digite 0\nSi quiere seguir digite cualquier otro numero");
			Ana = leer.nextInt();
			System.out.println("\n\n\n");
			
		}while(Ana!=0);
		System.out.println("PROGRAMA CERRADO..");
		System.exit(0);
	}
}
