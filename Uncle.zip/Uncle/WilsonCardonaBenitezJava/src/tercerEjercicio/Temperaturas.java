package tercerEjercicio;

import java.util.Scanner;

public class Temperaturas {
	
	void transformarARankine(double temperatura) {
		System.out.println("\n"+temperatura+" grados Centigrados es igual a: "+ ((temperatura * (9/5))+491.67)+ " grados Rankine");
	}
	
	void transformarAKelvin(double temperatura) {
		System.out.println("\n"+temperatura+" grados Centigrados es igual a: "+ (temperatura + 273.15)+ " grados Kelvin");
	}
	
	void transformarAFahrenheit(double temperatura) {
		System.out.println("\n"+temperatura+" grados Centigrados es igual a: "+ ((temperatura *1.8)+32)+" grados Fahrenheit");
	}
	
	public static void main(String[]args) {
		Scanner leer = new Scanner(System.in);
		Temperaturas tm = new Temperaturas();
		double temperatura;
		
		System.out.println("Digite la temperatura desada en grados Centigrados:\n\n");
		System.out.println("Grados Centigrados:");
		temperatura = leer.nextInt();
		tm.transformarAFahrenheit(temperatura);
		tm.transformarAKelvin(temperatura);
		tm.transformarARankine(temperatura);
	}

}
