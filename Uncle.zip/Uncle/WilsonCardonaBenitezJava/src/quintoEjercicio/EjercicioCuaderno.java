package quintoEjercicio;

import java.util.Scanner;

public class EjercicioCuaderno {
	
	void calcularAncho(double b) {
		double cuadradoAncho = b*2;
		cuadradoAncho -= 2;
		
		System.out.println("\nLa pagina tiene: "+(int)cuadradoAncho+" cuadrados de ancho");
	}
	
	void calcularLargo(double a){
		double cuadradoLargo = a*2;
		cuadradoLargo -= 4;
		
		System.out.println("\nLa pagina tiene: "+(int)cuadradoLargo+" cuadrados de largo");		
	}
	
	public static void main(String[]args) {
		Scanner leer = new Scanner(System.in);
		EjercicioCuaderno ec = new EjercicioCuaderno();
		double a=0, b=0;
		
		System.out.println("VALORES ANCHO Y LARGO DE LA PAGINA :\n\n");
		System.out.println("Digite el valor del largo en cm:");
		a = leer.nextDouble();
		
		System.out.println("Digite el valor del ancho en cm");
		b = leer.nextDouble();
		
		ec.calcularLargo(a);
		ec.calcularAncho(b);
		
	}
}
