package segundoEjercicio;

import java.util.Scanner;

public class MedidasLongitud {
	
	void transformarAAngstroms(double metros) {
		System.out.println("\n"+metros+" metros es igual a: "+ metros * 1000000000+ " Angstroms");
	}
	
	void transformarAA�osLuz(double metros) {
		System.out.println("\n"+metros+" metros es igual a: "+ metros * 0.0000000000000001057+ " A�os Luz");
	}
	
	void transformarAYardas(double metros) {
		System.out.println("\n"+metros+" metros es igual a: "+ metros * 1.09+ " Yardas");
	}
	
	void transformarAPulgadas(double metros) {
		System.out.println("\n"+metros+" metros es igual a: "+ metros * 39.3+ " Pulgadas");
	}
	
	void transformarAPies(double metros) {
		System.out.println("\n"+metros+" metros es igual a: "+ metros * 3.28+ " Pies");
	}
	
	void transformarAMilimetros(double metros) {
		System.out.println("\n"+metros+" metros es igual a: "+ metros * 1000+ " Milimetros");
	}
	
	void transformarACentimetros(double metros) {
		System.out.println("\n"+metros+" metros es igual a: "+ metros * 100+" Centimetros");
	}
	
	public static void main(String[]args) {
		Scanner leer = new Scanner(System.in);
		MedidasLongitud ml = new MedidasLongitud();
		double metros;
		
		System.out.println("Digite sus medidas en metros:\n\n");
		System.out.println("Metros:");
		metros = leer.nextInt();
		ml.transformarACentimetros(metros);
		ml.transformarAMilimetros(metros);
		ml.transformarAPies(metros);
		ml.transformarAPulgadas(metros);
		ml.transformarAYardas(metros);
		ml.transformarAA�osLuz(metros);
		ml.transformarAAngstroms(metros);
	}
}
