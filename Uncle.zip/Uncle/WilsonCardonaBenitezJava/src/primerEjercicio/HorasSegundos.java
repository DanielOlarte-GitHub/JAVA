package primerEjercicio;

import java.util.Scanner;

public class HorasSegundos {
	
	
	void transformarASegundos(int horas, int minutos, int segundos){
		int horasSegundos, minutosSegundos, totalSegundos;
		horasSegundos = horas * 3600;
		minutosSegundos = minutos * 60;
		totalSegundos = horasSegundos + minutosSegundos + segundos;
		
		System.out.println("El total de segundos de "+horas+" horas, "+minutos+" minutos y "+segundos+" segundos es:\n\t\t"+ totalSegundos+" SEGUNDOS");
	}
	
	public static void main(String[]args) {
		Scanner leer = new Scanner(System.in);
		HorasSegundos hs = new HorasSegundos();
		
		int  horas=0, minutos=0, segundos=0;
		
		do {
			System.out.println("DIGITE LA HORA ACTUAL (24H)\n\n\n");
			System.out.println("Hora:");
			horas = leer.nextInt();
			
			System.out.println("Minutos");
			minutos = leer.nextInt();
			
			System.out.println("Segundos");
			segundos = leer.nextInt();
		}while(horas>=24 || minutos>=60 || segundos>=60);
		
		hs.transformarASegundos(horas, minutos, segundos);
		
		
	}
}
