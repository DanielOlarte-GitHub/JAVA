package cuartoEjercicio;

import java.util.Scanner;

public class Ofertas {
	static Ofertas of = new Ofertas();
	Scanner leer = new Scanner(System.in);
	static double valorTienda1, valorTienda2, valorTienda3;
	
	
	double tienda3(double c, int num) {
		System.out.println("Total Tienda 3: "+c*num);
		return c*num;
	}
	
	double tienda2(double b, int num) {
		if(num==3) {
			System.out.println("Total Tienda 2:" + (b*2));
			return (b*2);
		}else {
			return b*num;
		}
		
	}
	
	double tienda1(double a, double d, int num) {
		if(num==3) {
			System.out.println("Total Tienda 1:" + (a*num)*d);
			return (a*num)*d;
		}else {
			return a*num;
		}
		
	}
	
	void colocarDatosDeTiendas(double a, double b, double c, double d) {
		System.out.println("TIENDA 1:\n\n");
		System.out.println("Digite el valor de la camiseta:");
		a = leer.nextDouble();
		
		System.out.println("Digite el descuento (0-1)");
		d = leer.nextDouble();
		
		System.out.println("\n\nTIENDA 2:\n\n");
		System.out.println("Digite el valor de la camiseta:");
		b = leer.nextDouble();
		
		System.out.println("\n\nTIENDA 3:\n\n");
		System.out.println("Digite el valor de la camiseta:");
		c = leer.nextDouble();
		
		valorTienda1 = of.tienda1(a, d, 3);
		valorTienda2 = of.tienda2(b, 3);
		valorTienda3 = of.tienda3(c, 3);
	}
	
	public static void main(String[]args) {
		
		double a=0, b=0, c=0, d=0;
		
		of.colocarDatosDeTiendas(a, b, c, d);
		
		
		
		if(valorTienda1 < valorTienda2 && valorTienda1 < valorTienda3) {
			System.out.println("La mejor opcion es la tienda numero 1 ");
		}else if(valorTienda2 < valorTienda1 && valorTienda2 < valorTienda3) {
			System.out.println("La mejor opcion es la tienda numero 2 ");
		}else {
			System.out.println("La mejor opcion es la tienda numero 3 ");
		}
		
	}
}
