package team;

public class Jugador {
	private String nombre, posicion;
	private int dorsal;
	private char pierna_buena;
	
	public Jugador(String nombre, int dorsal, char pierna_buena, String posicion) {
		this.nombre = nombre;
		this.dorsal = dorsal;
		this.pierna_buena = pierna_buena;
		this.posicion = posicion;
	}

	@Override
	public String toString() {
		return "Nombre = " + nombre + ", pierna_buena = " + pierna_buena + ", posicion = " + posicion + ", dorsal = "
				+ dorsal;
	}
		
}
