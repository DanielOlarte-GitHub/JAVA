package team;
import java.util.*;

public class Equipo {
	
	static ArrayList<Jugador> plantilla = new ArrayList<Jugador>();
	//static Iterator<Jugador> miIterador = plantilla.iterator();
	
	public static void main(String[]args) {
		agregar();
		mostrar();
		tama�o();
		//plantilla.ensureCapacity(11);
		//plantilla.trimToSize();
		consultar(0);
		agregarOtroLugar();
		mostrar();
		/*if(vacio()) {
			System.out.println("\nHay jugadores\n");
		}else {
			System.out.println("\nNo hay jugadores\n");
		}*/
		
	}
	
	/*public static boolean vacio() {
		return miIterador.hasNext();
	}*/
	
	public static void consultar(int jug) {
		System.out.println(plantilla.get(jug)+"\n");
	}
	
	public static void agregarOtroLugar() {
		plantilla.set(0, new Jugador("Ter Stegen", 1, 'I', "Portero"));
	}
	
	public static void tama�o() {
		System.out.println("\nHay en la lista un total de jugadores de: "+plantilla.size()+"\n");
	}
	
	public static void agregar() {
		
		plantilla.add(new Jugador("Alisson Becker", 1, 'D', "Portero"));
		plantilla.add(new Jugador("Thiago Silva", 2, 'D', "Defensa"));
		plantilla.add(new Jugador("Gerard Pique", 3, 'D', "Defensa"));
		plantilla.add(new Jugador("Sergio Ramos", 4, 'D', "Defensa"));
		plantilla.add(new Jugador("Sergio Busquets", 5, 'D', "Centro Campista"));
		plantilla.add(new Jugador("David Villa", 7, 'A', "Delantero"));
		plantilla.add(new Jugador("Radamel Falcao", 9, 'D', "Delantero"));
		plantilla.add(new Jugador("Neymar JR", 10, 'D', "Extremo"));
		plantilla.add(new Jugador("Mohamed Salah", 11, 'I', "Extremo"));
		plantilla.add(new Jugador("Dani Alves", 13, 'D', "Lateral Derecho"));
		plantilla.add(new Jugador("Jordi Alba", 18, 'I', "Lateral Izquierdo"));
		plantilla.add(new Jugador("Frenkie DeJong", 21, 'D', "Centro Campista"));
		
	}
	
	public static void mostrar() {
		for(Jugador recorrer: plantilla) {
			System.out.println(recorrer.toString()+"\n"); 	
		}
		
		/*
		while(miIterador.hasNext()) {
			System.out.println(miIterador.next().toString());
		}*/
				
		/*for(int i=0; i<plantilla.size(); i++) {
			Jugador j = plantilla.get(i);
			System.out.println(j.toString()+"\n");
		}*/
	}
	
	
}
