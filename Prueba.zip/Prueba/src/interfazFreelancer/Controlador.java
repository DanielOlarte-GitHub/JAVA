package interfazFreelancer;
import java.util.List;
import java.util.ArrayList;

public class Controlador {
 
     List<Modelo> temperaturas;

    // Llenar la lista
    public Controlador() {
        temperaturas = new ArrayList<>();
    }
    public void insertarTemperatura(Modelo temperatura) {
        temperaturas.add(temperatura);
        System.out.println("Se agregó la temperatura");
    }
     public Modelo obtenerTemperatura(String nombre) {
        for (Modelo temperatura : temperaturas) {
            if (temperatura.getNombre().equals(nombre)) {
                return temperatura;
            }
        }
        return null;
    }
    public void actualizarTemperatura(Modelo temperatura) {
        int i = 0;
        while (i < temperaturas.size()) {
            if (temperaturas.get(i).getNombre().equals(temperatura.getNombre())) {
                temperaturas.set(i, temperatura);
                System.out.println("Se modificó la temperatura");
                break;
            }
            i++;
        }
    }
    public void eliminarTemperatura(Modelo temperatura) {
        temperaturas.remove(temperatura);
        } 
     public List<Modelo> imprimirTemperatura(){
        return temperaturas;        
    }
}



   

