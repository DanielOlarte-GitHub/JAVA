package interfazFreelancer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author DANIEL
 */
public class Vista {

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) throws IOException {

		BufferedReader sc = new BufferedReader(new InputStreamReader(System.in));
		Controlador con = new Controlador();
		// Variables
		int opcion = 1;
		int correctas = 0;
		int incorrectas = 0;
		double promediomaximas = 0, promediominimas = 0, porcentajeerror = 0, porcentajecorrectas = 0, maxima = 0,
				minima = 0;
		while (opcion >= 1 && opcion <= 6) {
			System.out.println("");
			System.out.println("Universidad ECCI");
			System.out.println("Temperaturas");
			System.out.println("Seleccione tarea a realizar:");
			System.out.println("1. Ingresar Temperatura");
			System.out.println("2. Buscar Temperatura");
			System.out.println("3. Modificar Temperatura");
			System.out.println("4. Eliminar Temperatura");
			System.out.println("5. Ver Base de Datos de Temperaturas");
			System.out.println("6. Salir");
			System.out.println("Digite la Opción:");
			opcion = Integer.parseInt(sc.readLine());
			switch (opcion) {
			case 1:
				System.out.println("Ingresar Temperatura");
				Modelo nuevo = new Modelo();
				double a;
				double b;

				int x;
				x = 1;
				String nombre;
				System.out.println("Digite su nombre");
				nombre = sc.readLine();
				nuevo.setNombre(nombre);
				System.out.println("Ingresa la primera temperatura");
				a = Double.parseDouble(sc.readLine());
				nuevo.setA(a);
				System.out.println("Ingresa la segunda temperatura");
				b = Double.parseDouble(sc.readLine());
				nuevo.setB(b);
				if (a == 9 || b == 9) {
					incorrectas = incorrectas + 1;
					incorrectas++;
					nuevo.setIncorrectas(incorrectas);
					System.out.println("Las temperaturas son incorrectas");
				} else {
					correctas = correctas + 1;
					correctas++;
					nuevo.setCorrectas(correctas);
					if (a > b) {
						maxima = maxima + a;
						minima = minima + b;
					} else {
						maxima = maxima + b;
						minima = minima + a;
					}

				}
				promediomaximas = maxima / correctas;
				nuevo.setPromediomaximas(promediomaximas);
				promediominimas = minima / correctas;
				nuevo.setPromediominimas(promediominimas);
				porcentajeerror = (incorrectas / (incorrectas + correctas)) * 100;
				nuevo.setPorcentajeerror(porcentajeerror);
				porcentajecorrectas = (correctas / (incorrectas + correctas)) * 100;
				nuevo.setPorcentajecorrectas(porcentajecorrectas);
				con.insertarTemperatura(nuevo);

				break;
			case 2:
				System.out.println("Buscar Temperatura");
				System.out.println("Ingresar Nombre:");
				String buscar = sc.readLine();
				Modelo encontrado = con.obtenerTemperatura(buscar);
				if (encontrado != null) {
					System.out.println("Información de la temperatura");
					System.out.println("***********************");
					System.out.println("Nombre: " + encontrado.getNombre());
					System.out
							.println("El promedio de las temperaturas maximas es: " + encontrado.getPromediomaximas());
					System.out
							.println("El promedio de las temperaturas minimas es: " + encontrado.getPromediominimas());
					System.out
							.println("El porcentaje  de temperaturas con error es: " + encontrado.getPorcentajeerror());
					System.out.println(
							"El porcentaje  de temperaturas correctas es : " + encontrado.getPorcentajecorrectas());
					System.out.println("Temperaturas correctas: " + encontrado.getCorrectas());
					System.out.println("Temperaturas incorrectas: " + encontrado.getIncorrectas());
					System.out.println("***********************");
				} else {
					System.out.println("Temperatura no encontrada");
				}
				break;

			case 3:
				// MODIFICAR

				System.out.println("Modificar Empleado");
				Modelo actualizar = new Modelo();
				System.out.println("Ingresar Nombre:");
				buscar = sc.readLine();
				actualizar = con.obtenerTemperatura(buscar);
				System.out.println("Ingresar nombre del empleado");
				actualizar.setNombre(sc.readLine());
				System.out.println("Ingresa la primera temperatura");
				a = Double.parseDouble(sc.readLine());
				actualizar.setA(a);
				System.out.println("Ingresa la segunda temperatura");
				b = Double.parseDouble(sc.readLine());
				actualizar.setB(b);
				if (a == 9 || b == 9) {
					incorrectas = incorrectas + 1;
					System.out.println("Las temperaturas son incorrectas");
				} else {
					correctas = correctas + 1;
					if (a > b) {
						maxima = maxima + a;
						minima = minima + b;
					} else {
						maxima = maxima + b;
						minima = minima + a;
					}

				}
				promediomaximas = maxima / correctas;
				actualizar.setPromediomaximas(promediomaximas);
				promediominimas = minima / correctas;
				actualizar.setPromediominimas(promediominimas);
				porcentajeerror = (incorrectas / (incorrectas + correctas)) * 100;
				actualizar.setPorcentajeerror(porcentajeerror);
				porcentajecorrectas = (correctas / (incorrectas + correctas)) * 100;
				actualizar.setPorcentajecorrectas(porcentajecorrectas);
				con.actualizarTemperatura(actualizar);

				break;
			case 4:
				// ELIMINAR
				System.out.println("Eliminar Temperatura");
				System.out.println("Nombre:");
				buscar = sc.readLine();
				Modelo emp = con.obtenerTemperatura(buscar);
				con.eliminarTemperatura(emp);
				System.out.println("Se eliminó la temperatura");

				break;

			case 5:
				System.out.println("El directorio de las temperaturas");
				System.out.println(con.imprimirTemperatura());
				// });
				break;

			case 6:
				// SALIR
				System.out.println("Hasta Pronto");
				System.exit(0);

			default:
				System.out.println("Opcion no valida");
			}

		}

	}

}