package interfazFreelancer;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author DANIEL
 */
public class Modelo {
    String nombre;
    double a;
    double b;
    int correctas;
    int incorrectas;
    double promediomaximas,promediominimas,porcentajeerror,porcentajecorrectas, maxima,minima;
    int x;

    public Modelo() {
    }

    public Modelo(String nombre, double a, double b, int correctas, int incorrectas, double promediomaximas, double promediominimas, double porcentajeerror, double porcentajecorrectas, double maxima, double minima, int x) {
        this.nombre = nombre;
        this.a = a;
        this.b = b;
        this.correctas = correctas;
        this.incorrectas = incorrectas;
        this.promediomaximas = promediomaximas;
        this.promediominimas = promediominimas;
        this.porcentajeerror = porcentajeerror;
        this.porcentajecorrectas = porcentajecorrectas;
        this.maxima = maxima;
        this.minima = minima;
        this.x = x;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getA() {
        return a;
    }

    public void setA(double a) {
        this.a = a;
    }

    public double getB() {
        return b;
    }

    public void setB(double b) {
        this.b = b;
    }

    public int getCorrectas() {
        return correctas;
    }

    public void setCorrectas(int correctas) {
        this.correctas = correctas;
    }

    public int getIncorrectas() {
        return incorrectas;
    }

    public void setIncorrectas(int incorrectas) {
        this.incorrectas = incorrectas;
    }

    public double getPromediomaximas() {
        return promediomaximas;
    }

    public void setPromediomaximas(double promediomaximas) {
        this.promediomaximas = promediomaximas;
    }

    public double getPromediominimas() {
        return promediominimas;
    }

    public void setPromediominimas(double promediominimas) {
        this.promediominimas = promediominimas;
    }

    public double getPorcentajeerror() {
        return porcentajeerror;
    }

    public void setPorcentajeerror(double porcentajeerror) {
        this.porcentajeerror = porcentajeerror;
    }

    public double getPorcentajecorrectas() {
        return porcentajecorrectas;
    }

    public void setPorcentajecorrectas(double porcentajecorrectas) {
        this.porcentajecorrectas = porcentajecorrectas;
    }

    public double getMaxima() {
        return maxima;
    }

    public void setMaxima(double maxima) {
        this.maxima = maxima;
    }

    public double getMinima() {
        return minima;
    }

    public void setMinima(double minima) {
        this.minima = minima;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    @Override
    public String toString() {
        return "Modelo{" + "nombre=" + nombre + ", a=" + a + ", b=" + b + ", correctas=" + correctas + ", incorrectas=" + incorrectas + ", promediomaximas=" + promediomaximas + ", promediominimas=" + promediominimas + ", porcentajeerror=" + porcentajeerror + ", porcentajecorrectas=" + porcentajecorrectas + ", maxima=" + maxima + ", minima=" + minima + ", x=" + x + '}';
    }

    
    
    
}


 
      

