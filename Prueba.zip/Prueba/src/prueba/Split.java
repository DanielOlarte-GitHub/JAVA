package prueba;


public class Split {
	public static void main(String[] args) {
		int cadena = 123;
		String cad = String.valueOf(cadena);
		String[] nueva ;
		
		nueva = cad.split("");
		
		System.out.println(nueva[1]);
		
	}
}
