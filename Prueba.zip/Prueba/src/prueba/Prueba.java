package prueba;
/*
Pedir por pantalla cuatro n�meros al azar. Primero pedir dos n�meros y sumarlos. 
Segundo pedir  otros dos n�meros y multiplicarlos. Luego Dividir los dos resultados. 
Todos los resultados deben ser impresos en la pantalla con sus respectivos Titulares.

Trabajo por: Carlos Andres Jimenez
*/

import java.util.Scanner;

public class Prueba {
	
	
	public static void main(String[]args) {
		
		Scanner leer = new Scanner(System.in);
		System.out.println("\t\tEJERCICIO 4 NUMEROS SUMA MULTIPLICACION Y DIVISION\n");
		
		//VARIABLES
		int rep = 1;
		double numero1, numero2, numero3, numero4, suma, multiplicacion, division;
		
		while(rep!=0){
			System.out.print("\n\t\tDigite el valor del numero 1 = ");
			numero1 = leer.nextDouble();
			
			System.out.print("\n\t\tDigite el valor del numero 2 = ");
			numero2 = leer.nextDouble();
			
			suma = numero1 + numero2;
			
			System.out.print("\n\t\tDigite el valor del numero 3 = ");
			numero3 = leer.nextDouble();
			
			System.out.print("\n\t\tDigite el valor del numero 4 = ");
			numero4 = leer.nextDouble();
			
			multiplicacion = numero3 * numero4;
			
			division = suma / multiplicacion;
			
			System.out.println("\n\n\t\tDATOS:\n");
			System.out.println("Numero 1: "+ numero1);
			System.out.println("Numero 2: "+ numero2);
			System.out.println("Numero 3: "+ numero3);
			System.out.println("Numero 4: "+ numero4);
			System.out.println("Suma entre numero 1 y numero 2: "+suma);
			System.out.println("Multiplicacion entre numero 3 y numero 4: "+ multiplicacion);
			System.out.println("Division (numero1+numero2)/(numero3*numero4): "+division);

			System.out.println("MENU");
			System.out.println("Desea repetir el ejercicio?\n\t\tDigite 0: SALIR\n\t\tDigite otro numero: CONTINUAR\n ");
			rep = leer.nextInt();
			
		}
		
		System.out.println("MUCHAS GRACIAS");
		
		
	}
	
}