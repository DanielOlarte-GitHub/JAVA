package prueba;

import java.util.Scanner;

/*
 * 
 * 0 = DISPONIBLE
 * 1 = NO DISPONIBLE
 * 
 * 
       0	1	2	3	4	5	6	7	8	9 
  0	   0	0	0	0	0	0	0	0	0	0
  1	   0	0	0	0	0	0	0	0	0	0
  2	   0	0	0	0	0	0	0	0	0	0
  3	   0	0	0	0	0	0	0	0	0	0
  4    0	0	0	0	0	0	0	0	0	0
  5    0	0	0	0	0	0	0	0	0	0
  6
  7
  8
  9
  
  
 
 */
public class Estadio {
	
	static int [][] estadio = new int[10][10];
	static Scanner teclado = new Scanner(System.in);
	
	static public void menu() {
		int opcion;
		System.out.println("MENU:\n");
		System.out.println("1) Comprar");
		System.out.println("0) Salir");
		opcion = teclado.nextInt();
		
		switch(opcion) {
		case 1:
			
		break;
		
		case 2:
			
		break;
		
		case 3:
			
		break;
		
		case 4:
			
		break;
		
		case 0:
			System.exit(0);
		break;
		
		default:
			
		break;	
		}
		
		menu();
		
	}
	
	static public void mostrarEstadio() {
		for(int i=0; i<10; i++) {
			for(int j=0; j<10; j++) {
				System.out.print(estadio[i][j]+"   ");
			}
			
			System.out.println("\n");
		}
	}
	
	//METODO PARA LLENAR TODAS LAS SILLAS CON 0'S
	static public void llenarEstadio() {
		for(int i=0; i<10; i++) {
			for(int j=0; j<10; j++) {
				estadio[i][j] = 0;
			}
		}
	}
	
	//METODO PRINCIPAL MAIN
	public static void main(String[] args) {
		llenarEstadio();		
		mostrarEstadio();
		menu();
		
		//menu
		//quiero comprar!
		// yo quiero comprar fila 4 columna 6
		estadio[4][6] = 1;
		
		System.out.println("\n\n///////////////////////////////////////\n\n");
		mostrarEstadio();
		
		
	}
}
