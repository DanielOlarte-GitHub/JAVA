package prueba;

import java.util.Random;

public class Luhj {
	public static void main(String[]args) {
		String numTt = "", numTtLuhj = "";
		int aux= 0;
		Random numR = new Random();
		
			for(int i = 0; i < 15; i++) {
				numTt += Integer.toString(numR.nextInt(10));
			
			}
			
		
			System.out.println(numTt+"\n\n");
			
			for(int i = 0; i<15; i++) {
				
				aux = numTt.charAt(i)-48;
				if((i+1)%2 == 0 ) {
					aux *= 1;
					numTtLuhj += Integer.toString(aux);
				}else {
					aux *= 2;
					
					if(aux >=10) {
						aux = 1+(aux%10);
					}
					numTtLuhj += Integer.toString(aux);
				}
			}
			
			System.out.println(numTtLuhj+"\n\n");
			
			int sum=0, NumLuhj;
			for(int i=0; i<15; i++) {
				sum += numTtLuhj.charAt(i)-48;
			}
			
			NumLuhj = 10 - (sum%10);
			sum+=NumLuhj;
			numTt += NumLuhj;
			System.out.println(NumLuhj);
			System.out.println(numTt);
			System.out.println(sum+"\n\n");
	}
	/*
	
		*/
}
