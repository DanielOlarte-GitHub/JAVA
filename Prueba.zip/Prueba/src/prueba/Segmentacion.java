package prueba;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class Segmentacion {
	public static void main(String[] args) {
		Scanner leer = new Scanner(System.in);
		ArrayList<String> arregloD = new ArrayList<>();
		//hola
		//2 ho la
		//3 00 ho la
		//4 h o l a
		//5 0 h o l a
		int partes, tamanio;
		String cadena;
		
		System.out.println("Digite la cadena: ");
		cadena = leer.next();
		System.out.println("Digite en cuantas partes quiere segmentar la cadena:");
		partes = leer.nextInt();
		
		tamanio = cadena.length();
		
		for(int i=0; i<partes; i++) {
			
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
