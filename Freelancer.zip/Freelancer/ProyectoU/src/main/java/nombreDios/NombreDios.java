
package nombreDios;

/**
 * LEER PRIMERO
 * 
 * Para el ejercicio del nombre de Dios podemos saber que es un ejercicio de permutacion puesto que tiene
 * tres requerimientos:
 * 1) Se pueden repetir los datos
 * 2) Importa el orden
 * 3) No se puede repetir 3 veces seguidas una misma letra
 * 
 * Para esto se usa con arreglo de 30, referenciandolo a las 30 letras del abecedario de los monjes tibetanos
 * donde cada numero se refiere a cada letra, asi hacer la permutacion mas facil y tambien las condiciones,
 * y a la hora de imprimir los nombres reemplazar los numeros por su respectiva letra
 * 
 * ya que son 30 letras del abecedario y el nombre pueden ser hasta 9 letras se usa la formula
 * 30P9
 * 
 * 1 = ka                       2 = kha                     3 = ga                       4 = nga
 * 5 = ca                       6 = cha                     7 = ja                       8 = nya
 * 9 = ta                      10 = tha                    11 = da                      12 = na
 * 13 = pa                     14 = pha                    15 = ba                      16 = ma
 * 17 = tsa                    18 = tsha                   19 = dza                     20 = wa
 * 21 = zha                    22 = za                     23 = 'a                      24 = ya
 * 25 = ra                     26 = la                     27 = sha                     28 = sa 
 * 29 = ha                     30 = a
 * 
 */


public class NombreDios {
    public static void main (String[]args){
        //Un arreglo con todo el abecedario para agregar por indice al nombre e imprimirlos
        String abecedario[] = {"ka","kha","ga","nga","ca","cha","ja","nya","ta","tha","da","na","pa","pha","ba","ma","tsa","tsha","dza","wa","zha","za","'a","ya","ra","la","sha","sa","ha","a"};
        //Se crea el arreglo del nombre sabiendo que va a tener 9 letras del abecedario
        int nombre[] = new int[9];
      
        imprimirAbecedario(abecedario);
        cantPermutacion(abecedario);
        permutaciones(abecedario, nombre, 0);
    }
    
    //Se imprime el abecedario para mostrarle al Usuario que letras se van a tener en cuenta
    public static void imprimirAbecedario(String[] abecedario){
        System.out.println("\n\n\t\t\t\t\tABECEDARIO DE MONJES TIBETANOS:\n\n");
        for(int i=0; i<30;i++){
            System.out.println(abecedario[i]);
        }
        System.out.println("\n\n\t\t\t\t\tFIN ABECEDARIO\n\n\n\n");
        
    }
    
    //Se calcula la cantidad de permutaciones 
    public static void cantPermutacion(String[] abecedario){
       double n ,k; //30 P 9 = !n/ !(n-k)
       n = abecedario.length;
       k = 9;
       double nF = factorial(n);
       double nkF = factorial((n-k));
       double resultado = nF/nkF;
       System.out.println("\nLA CANTIDAD DE PERMUTACIONES POSIBLES ES DE: "+resultado+"\n\n\n");
    }
    
    //Metodo recursivo para agregar las letras al nombre
    public static void permutaciones(String[] abecedario, int[] nombre, int letra){
        //manda a otro metodo el nombre creado para revisarlo
        if( letra==nombre.length){
            
            condicionNombre(nombre);
            
        } else if(letra!=nombre.length){
            for (int i = 1; i <= 30; i++) {
                nombre[letra] = i;
                permutaciones(abecedario, nombre,(letra+1));
          
            }
        }
    }
    
    //Metodo para saber si el nombre recibido cumple los requerimientos pedidos 
    public static void condicionNombre(int[] nombre){
        boolean entra = true;
        int aux;
        //for para recorrer el nombre para comprobar los requerimientos
        for(int i=0; i<nombre.length;i++){
            aux = i; //Variable auxiliar para no mezclar la variable i del for y asegurar que no ocurran errores 
            //if para poder usar las siguientes 2 letras de la que esta, y no salga error al usar un indice fuera del tamaño del arreglo
            if(i<(nombre.length-2)){
                //if para revisar que la letra no se repita 3 veces seguidas en el nombre
                if(nombre[aux]==nombre[(aux+1)] && nombre[aux]==nombre[(aux+2)]){
                    entra = false;//si se repite bandera falsa para que no imprima ese nombre
                    break;//y se cierra el for diciendo que ese nombre ya no sirve para que llegue el siguiente
                }
            }
        }
        //Si el nombre cumple los requerimientos se envia al metodo para imprimirlo
        if(entra==true){
            imprimirNombres(nombre);
        }
    }
    
    //Metodo para imprimir el posible nombre
    public static void imprimirNombres(int nombre[]){
        for(int j = 0; j < nombre.length; j++){
            if(nombre[j]!=0){    
                //Switch para imprimir la letra en especifica para formar el nombre
                switch(nombre[j]){
                    case 1:
                        System.out.print("ka");
                    break;
                    
                    case 2:
                        System.out.print("kha");
                    break;
                    
                    case 3:
                        System.out.print("ga");
                    break;
                    
                    case 4:
                        System.out.print("nga");
                    break;
                    
                    case 5:
                        System.out.print("ca");
                    break;
                    
                    case 6:
                        System.out.print("cha");
                    break;
                    
                    case 7:
                        System.out.print("ja");
                    break;
                    
                    case 8:
                        System.out.print("nya");
                    break;
                    
                    case 9:
                        System.out.print("ta");
                    break;
                    
                    case 10:
                        System.out.print("tha");
                    break;
                    
                    case 11:
                        System.out.print("da");
                    break;
                    
                    case 12:
                        System.out.print("na");
                    break;
                    
                    case 13:
                        System.out.print("pa");
                    break;
                    
                    case 14:
                        System.out.print("pha");
                    break;
                    
                    case 15:
                        System.out.print("ba");
                    break;
                    
                    case 16:
                        System.out.print("ma");
                    break;
                    
                    case 17:
                        System.out.print("tsa");
                    break;
                    
                    case 18:
                        System.out.print("tsha");
                    break;
                    
                    case 19:
                        System.out.print("dza");
                    break;
                    
                    case 20:
                        System.out.print("wa");
                    break;
                    
                    case 21:
                        System.out.print("zha");
                    break;
                    
                    case 22:
                        System.out.print("za");
                    break;
                    
                    case 23:
                        System.out.print("'a");
                    break;
                    
                    case 24:
                        System.out.print("ya");
                    break;
                    
                    case 25:
                        System.out.print("ra");
                    break;
                    
                    case 26:
                        System.out.print("la");
                    break;
                    
                    case 27:
                        System.out.print("sha");
                    break;
                    
                    case 28:
                        System.out.print("sa");
                    break;
                    
                    case 29:
                        System.out.print("ha");
                    break;
                    
                    case 30:
                        System.out.print("a");
                    break;                    
                    
                }
                
            }
        }
        System.out.println("\n\n");
    }
    
    //metodo para sacar el factorial para la ecuacion
    public static double factorial(double n){
        long res = 1;
        for (int i = 1; i <= n; i++) {
            res *= i;//opcion resumida de la operacion completa,funciona igual que res = res*i
        }
        return res;
    }
}

