
package musas;

import java.util.Scanner;

/**
 * LEER PRIMERO 
 * 
 * Para el ejercicio de las musas podemos saber que es un ejercico de combinatoria puesto que se cumplen
 * tres requerimientos: 
 * 1) No se pueden repetir los datos
 * 2) No importa el orden
 * 3) No todos se incluyen (en cada conjunto no pueden estar las 9 musas)
 * 
 * Al saber esto la ecuacion es sencilla, donde es nCm 
 * donde: 
 *       n = cantidad total de la muestra (para el ejercicio: 9)
 *       m = cantidad total por grupo (para el ejercicio: 3)
 * 
 * la ecuaciÃ³n de combinatoria es:
 *      C = n!/ (m!(n-m)!)
 * El resultado de la ecuaciÃ³n determina la cantidad de conjuntos que podemos hacer cumpliendo los tres
 * requirimientos anteriores
 * 
 * El programa tiene una entrada manual de datos para que funcione no solamente para el ejemplo, pero
 * si no lo desea de esa manera, puede comentar las lineas 55,58,59,63,64 y quitar el comentario de las 
 * lÃ­neas 60,65 y el programa funciona con el ejercicio de las musas solamente
 * 
 * El programa hace por separado el calculo de los tres factoriales (n!,m!(n-m)!) y son asignados 
 * a las variables num, dem1 y dem2 respectivamente 
 * Una vez obtenido los resultados individuales en la variable comb se realiza la operaciÃ³n para calcular
 * la cantidad re conjuntos posibles
 * 
 * El mÃ©todo factorial se encarga de recibir el numero que se desea realizar el factorial y retornar el
 * resultado, funciona en un ciclo for desde 1 hasta el valor enviado al mÃ©todo multiplicandose el valor
 * anterior por el siguiente (resultado = resultado*i) 
 * 
 * AUNQUE EL PROGRAMA ESTA REALIZADO PARA QUE FUNCIONE CON OTROS VALORES, DBIDO A QUE EL FACTORIAL SE 
 * CONVIERTE EN UN VALOR EXTREMADAMENTE GRANDE, SOLO ALCANZA A REALIZAR SIN ERRORES HASTA 20!, VALORES 
 * SIGUIENTES AL 20 NO FUNCIONAN, PARA QUE FUNCIONEN SE DEBE CAMBIAR EL TIPO DE DATO DE num,dem1,dem2,comb
 * Y EL METODO factorial PARA QUE FUNCIONEN CON EL TIPO DE DATO BIGINTEGER, AL HACER ESE CAMBIO SI 
 * PUEDE SOPORTAR EL PROGRAMA VALORES MAYORES A 20!
 */
public class Musas {

    
    public static void main(String[] args) {     
        Scanner leer = new Scanner(System.in);
        
        System.out.println("\n\n\t\t\t\t\tBienvenido al ejercicio Musas\n\n\n");
        
        //muestra
        System.out.println("Ingrese la cantidad total de musas");
        int n = leer.nextInt();
        //int n = 9;
        
        //grupos
        System.out.println("Ingrese la cantidad de musas que debe haber en cada agrupacion");
        int m = leer.nextInt();        
        //int m = 3;
        
        //operaciones
        //factorial cantidad total muestra
        long num = factorial(n);
        //factorial cantidad por grupo
        long dem1 = factorial(m);
        //factorial diferencia muestra/grupos
        long dem2 = factorial(n-m);
        //operacion combinatoria sin repeticiones
        long comb = num / (dem1 * dem2);
        //resultado cantidad de combinaciones
        System.out.println("En este ejercicio la cantidad de posibles soluciones es de: " + comb);
        
    }

    private static long factorial(int n) {
        long res = 1;
        for (int i = 1; i <= n; i++) {
            res *= i;//opcion resumida de la operacion completa,funciona igual que res = res*i
        }
        return res;
    }
}
