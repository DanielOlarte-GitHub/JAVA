package matematicas;

/**
 *
 * @author Jostiben
 * @author Sharon Diaz
 */




/**
 * Ejemplo de Matriz
 * 1 0 0 1
 * 0 1 1 0
 * 0 0 1 0
 * 1 0 0 1
 */

import java.util.Random;
import java.util.Scanner;

public class Matematicas {
	static boolean banderaReflex = false, banderaSimetr = false, banderaTransit = false, banderaAntisimet = false,
			banderaIrreflex = false, bandera = true, simetrica = true;;
	static int tamano;
	static int matriz[][];

	public static Integer getRandomNumber(int min, int max) {
		return new Random().nextInt(max - min + 1) + min;
	}

	public static void Automatico() {
		ImprimirGrafoMatriz();
		RelacionReflexivaIrreflexiva();
		RelacionSimetricaAsimetricaAntisimetrica();
		RelacionTransitiva();
		RelacionEquivalencia();
		RelacionOrdenParcialTotalEstricto();

	}

	public static void RelacionOrdenParcialTotalEstricto() {

		// ORDEN PARCIAL (Reflexiva, Antisimetrica, y Transitiva)
		if (banderaReflex == true && banderaAntisimet == true && banderaTransit == true) {
			System.out.println("");
			System.out.println("Cumple con la Relacion de Orden Parcial");
		}

		// ORDEN TOTAL (Reflexiva, Antisimetrica, Transitiva y Lineal(Total)
		if (banderaReflex == true && banderaAntisimet == true && banderaTransit == true ) {
			System.out.println("");
			System.out.println("Cumple con la Relacion de Orden Total");
		}

		// ORDEN ESTRICTO (Irreflexiva, Antisimetrica, Transitiva)
		if (banderaIrreflex == true && banderaAntisimet == true && banderaTransit == true) {
			System.out.println("");
			System.out.println("Cumple con la Relacion de Orden Estricto");
		}
	}

	public static void RelacionEquivalencia() {
		// RELACION EQUIVALENCIA (reflexiva, simetrica, y transitiva)
		if (banderaReflex == true && banderaSimetr == true && banderaTransit == true) {
			System.out.println("");
			System.out.println("La relacion es de Equivalencia");
		} else {
			System.out.println("");
			System.out.println("La relacion No es de Equivalencia");
		}
	}

	public static void MultiplicacionMatrices(int[][] matrizNueva) {
		// MULTIPLICACION MATRICES

		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz[0].length; j++) {
				for (int k = 0; k < matriz[0].length; k++) {
					// aqu� se multiplica la matriz
					matrizNueva[i][j] += matriz[i][k] * matriz[k][j];
				}
			}
		}

	}

	public static void RelacionTransitiva() {
		int[][] matrizNueva = new int[matriz.length][matriz[0].length];
		MultiplicacionMatrices(matrizNueva);
		// RELACION TRANSITIVA
		bandera = true;
		for (int i = 0; i < tamano; i++) {
			for (int j = 0; j < tamano; j++) {
				if (matriz[i][j] < matrizNueva[i][j]) {
					bandera = false;
				}
			}
		}

		if (bandera == true) {
			System.out.println("");
			System.out.println("La relacion es Transitiva");
			banderaTransit = true;
		}else {
			System.out.println("");
			System.out.println("La relacion No es Transitiva");
		}

	}

	public static void RelacionSimetricaAsimetricaAntisimetrica() {

		// Relacion Simetrica

		int i = 0, j;
		i = 0;
		while (i < tamano && simetrica == true) {

			j = 0;
			while (j < i && simetrica == true) {

				if (matriz[i][j] != matriz[j][i]) {
					simetrica = false;

				}
				j++;
			}
			i++;
		}

		if (simetrica == true) {
			System.out.println("");
			System.out.println("La relacion es Simetrica");
			banderaSimetr = true;
			// Relacion Asimetrica
		} else if (simetrica == false) {

			for (int a = 0; a < tamano; a++) {
				for (int b = 0; b < tamano; b++) {
					if (a != b) {
						if (matriz[a][b] == matriz[b][a]) {
							bandera = false;
						}
					} else {
						if (matriz[a][b] != 0) {
							bandera = false;
						}
					}

				}
			} // Relacion Asimetrica
			if (bandera == true) {
				System.out.println("");
				System.out.println("La relacion es Asimetrica");

				// ANTISIMETRICA
				/*
				 * 1 0 0 1 1 1 -> INVALIDA 0 0
				 */
			} else {
				bandera = true;
				for (int a = 0; a < tamano; a++) {
					for (int b = 0; b < tamano; b++) {
						if (a != b) {
							if (matriz[a][b] == 1 && matriz[b][a] == 1) {
								bandera = false;
							}
						}
					}
				}
				if (bandera == true) {
					System.out.println("");
					System.out.println("La relacion es Anti simetrica");
					banderaAntisimet = true;
				}else {
					System.out.println("");
					System.out.println("La relacion no es Simetrica, Asimetrica ni Anti simetrica");
				}
			}
		}

	}

	public static void RelacionReflexivaIrreflexiva() {
		int aux = 0, cont = 0;

		// Recorre Diagonal
		for (int i = 0; i < tamano; i++) {

			if (matriz[aux][aux] == 1) {
				aux++;
				cont++;
			}
		}

		// Si la diagonal es correcta con 1 Es reflexiva
		if (cont == tamano) {
			System.out.println(" ");
			System.out.println("La relacion es Reflexiva");
			banderaReflex = true;
		}else{
			System.out.println(" ");
			System.out.println("La relacion es Irreflexiva");
			banderaIrreflex = true;
		}
	}

	public static void ImprimirGrafoMatriz() {
		System.out.println("Su Grafo Matriz es: ");
		System.out.print("   ");
		for (int i = 0; i < tamano; i++) {
			System.out.print("  " + i);
		}
		System.out.println("\n");
		for (int i = 0; i < tamano; i++) {
			for (int j = 0; j < tamano; j++) {
				if (j == 0) {
					System.out.print(i + "    ");
				}
				System.out.print(matriz[i][j] + "  ");
			}
			System.out.println("");
		}
	}

	public static void menu() {
		Scanner leer = new Scanner(System.in);
		System.out.println("\n\nMENU:");
		System.out.println("Escoja una opcion:");
		System.out.println("1. Imprimir Grafo Matriz");
		System.out.println("2. Mostrar de Manera automatica todas las relaciones");
		System.out.println("3. Relacion Reflexiva o Irreflexiva");
		System.out.println("4. Relacion Simetrica, Asimetrica o Antisimetrica");
		System.out.println("5. Relacion Transitiva");
		System.out.println("6. Relacion Equivalencia");
		System.out.println("7. Relacion Orden Parcial, Total o Estricto");
		System.out.println("0. Salir");
		System.out.print("Digite Su Opcion: ");
		int opcion = leer.nextInt();

		switch (opcion) {
		case 1:
			ImprimirGrafoMatriz();
			break;

		case 2:
			Automatico();
			break;

		case 3:
			RelacionReflexivaIrreflexiva();
			break;

		case 4:
			RelacionSimetricaAsimetricaAntisimetrica();
			break;

		case 5:
			RelacionTransitiva();
			break;

		case 6:
			RelacionEquivalencia();
			break;

		case 7:
			RelacionOrdenParcialTotalEstricto();
			break;

		case 0:
			System.exit(0);
			break;

		default:
			System.out.println("DIGITO UN VALOR INVALIDO, INTENTE DE NUEVO");
			break;
		}
		menu();
	}

	public static void crearMatriz() {
		System.out.println("CREANDO MATRIZ");

		System.out.println("ingrese el tamaño de la matriz");
		tamano = Leer.datoInt();
		matriz = new int[tamano][tamano];
		System.out.println("Como desea rellenar esta matriz");
		System.out.println("1. personalmente\n" + "2. de manera alteratoria");
		int op = Leer.datoInt();

		if (op == 1) {
			System.out.println("ingrese los valores de la matriz");
			for (int i = 0; i < tamano; i++) {
				for (int j = 0; j < tamano; j++) {

					System.out.println("[" + i + "] [" + j + "]");
					matriz[i][j] = Leer.datoInt();
				}

			}
		} else if (op == 2) {
			for (int i = 0; i < tamano; i++) {
				for (int j = 0; j < tamano; j++) {
					matriz[i][j] = getRandomNumber(0, 1);

				}
			}
		} else {

			System.out.println("Digito un valor incorrecto");
			return;
		}
	}

	public static void main(String[] args) {
		System.out.println("CODIGO RELACIONES DE MATRICES");
		crearMatriz();
		ImprimirGrafoMatriz();
		menu();
	}
}
