package tFinal;

import java.util.Scanner;

public class Principal {
	//Scanner para leer datos que digite el usuario
	static Scanner leer = new Scanner(System.in);
	
	//Guarda el nombre y cuenta vocales apra saber cuantas hay y cuantas consonantes
	public static void funcion() {
		
		//Variables
		String nombre;
		int contVocales=0,contEspacios=0;
		//Se guarda el nombre
		System.out.println("\nEscriba un nombre a continuacion: ");
		nombre = leer.nextLine();

		System.out.println("\nBienvenido "+nombre);
		
		//Cuenta vocales y cuantos espacios hay
		for(int i=0; i<nombre.length(); i++) {
			if(nombre.charAt(i)=='a'||nombre.charAt(i)=='A'||nombre.charAt(i)=='e'||nombre.charAt(i)=='E'||nombre.charAt(i)=='i'||nombre.charAt(i)=='I'||nombre.charAt(i)=='o'||nombre.charAt(i)=='O'||nombre.charAt(i)=='u'||nombre.charAt(i)=='U'){
				contVocales++;
			}else if(nombre.charAt(i)==' ') {
				contEspacios++;
			}
		}
		
		//Imprime resultados
		System.out.println("\nEl nombre tiene: ");
		System.out.println(nombre.length()-contEspacios+" Letras");
		System.out.println(contVocales+" Vocales");
		System.out.println((nombre.length()-contVocales)-contEspacios+" Consonantes\n");
	}
	
	
	//Menu del codigo
	public static void menu() {
		int men;
		System.out.println("\nMenu (Escriba una opcion)");
		System.out.println("1. Escriba el nombre y mostrar informacion");
		System.out.println("2. Salir");
		men = leer.nextInt();
		leer.nextLine();
		if(men == 1) {
			funcion();
		}else if(men == 2) {
			System.exit(0);
		}else {
			System.out.println("Intentelo de nuevo");
		}
		menu();
	}
	
	//Metodo Main
	public static void main(String[] args) {
		System.out.println("Bienvenido\n");
		menu();
	}
}
