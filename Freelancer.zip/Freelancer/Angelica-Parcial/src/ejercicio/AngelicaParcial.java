//Parcial hecho por: Angelica Garcia
package ejercicio;

import java.util.Scanner;

/*
 * Hacer un programa que pida por pantalla 
 * 
 * 1. Nombre y edad al usuario
 * 2. Haciendo uso de la edad debe calcular el a�o que nacio
 * 3. Al obtener un a�o ej. 1964 debe sumar los digitos: 1+9+6+4=20
 * 4. Imprimir todos los resultados con sus titulos correspondientes
 */
public class AngelicaParcial {

	// Metodo principal del programa
	public static void main(String[] args) {
		// Scanner para leer lo que digite el usuario
		Scanner teclado = new Scanner(System.in);
		// VARIABLES que se usaran en el programa
		String respuesta, nombre, anioS;
		int edad, anio, suma;
		
		System.out.println("PROGRAMA DE SUMA DE LOS DIGITOS DEL A�O DE NACIMIENTO");
		
		// Ciclo para repetir el codigo si lo desea el usuario
		do {
			// Se pregunta y guarda el nombre ingresado
			System.out.println("\nIngrese el nombre");
			nombre = teclado.next();
			// Se pregunta y guarda la edad para hallar el a�o en que nacio
			System.out.println("Digite la edad");
			edad = teclado.nextInt();

			// Se calcula el a�o de nacimiento restando el a�o actual con la edad
			anio = 2022 - edad;
			// Se convierte el a�o en una cadena String para poder sacar digito por digito
			anioS = String.valueOf(anio);

			// Se convierte cada digito a entero de nuevo restandole una cadena de 0 debido
			// a que cuando no se hace esto, el entero que queda en la variable es el del
			// codigo ASCII del caracter
			int digito1 = anioS.charAt(0) - '0';
			int digito2 = anioS.charAt(1) - '0';
			int digito3 = anioS.charAt(2) - '0';
			int digito4 = anioS.charAt(3) - '0';

			// Se suma cada digito del a�o (el a�o tiene 4 numeros en posicion va de 0-3)
			suma = digito1 + digito2 + digito3 + digito4;

			// RESULTADOS
			System.out.println("\n\nRESULTADOS");
			System.out.println("El nombre ingresado es: " + nombre);
			System.out.println("La edad ingresada es: " + edad);
			System.out.println("\nEl a�o es: " + anio);

			// Se imprimen los digitos separados
			System.out.println("El primer digito del a�o de nacimiento es: " + digito1);
			System.out.println("El segundo digito del a�o de nacimiento es: " + digito2);
			System.out.println("El tercer digito del a�o de nacimiento es: " + digito3);
			System.out.println("El cuarto digito del a�o de nacimiento es: " + digito4);
			// Se imprime la suma
			System.out.println("\nLa suma de los digitos es: " + suma + "\n\n");

			// Se pregunta si se desea repetir el programa si digita s o S se repite, en el
			// caso que digite cualquier otro valor no se repetira
			System.out.println("Quiere repetir el programa? s/n");
			respuesta = teclado.next();
			System.out.println("\n\n\n");
		} while (respuesta.equals("s") || respuesta.equals("S"));

		System.out.println("\n\n\nGRACIAS POR USAR EL PROGRAMA");
	}
}