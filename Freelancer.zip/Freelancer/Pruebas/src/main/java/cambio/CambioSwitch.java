
package cambio;

import java.util.Scanner;

public class CambioSwitch {
    static int opc, comp = 1;
    static Scanner leer = new Scanner(System.in);
    
    
    public static void main(String[]args){
        menu();
    }
    
        
    public static void menu(){
        System.out.println("Dijite 0 para simular compilado");
        opc = leer.nextInt();
        switch(opc){
            case 0:
              compilar();
            break;
            
            default:
                System.out.println("Se salio");
            break;    
        }
        menu();
    }
    
    public static void compilar(){
        if(comp==1){
            System.out.println("Se hace proceso 1");
            comp++;
        }else{
            System.out.println("Se hace proceso 2");
            comp--;
        }
        
    }
}
