package cambio;

import java.util.*;

public class laberinto {
    
    public static void main(String[] args) {
    
        
    }
}
