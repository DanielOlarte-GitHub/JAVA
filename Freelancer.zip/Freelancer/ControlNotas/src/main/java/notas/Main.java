package notas;

import java.util.Scanner;

public class Main {
	/*EJEMPLO:	3 MATERIAS 			3 NOTAS      2 Extra    (2+cantNotas) * cantMat
	  Total 12columnas 2 filas								i  %  4 = 0
	  														8  %  4 = 0
	*/														
	/**
	 * 		0		1	   2	   3	  4	     5		6	     7	    8       9       10    11                           
	 * 0 Espa�ol: Nota1  Nota2    Prom   Ingles:  Nota1  Nota2  Prom   Matem:  Nota1   Nota2 Prom
	 * 
	 * 1            2      3	  2.5               3      4     3.5                           
	 *  
	 */
	
	//Arreglo de Objetos donde estaran todos los estudiantes con sus respectivas notas y promedios
	static Estudiante estudiantes[];
	//Matriz principal donde estaran las notas y promedios del nuevo estudiante 
	static String matriz[][];	
	//Arreglo que tengra los nombres de las materias 
	static String materias[];
	//Demas variables necesarias para el codigo
	static int cantNotas, cantMaterias, cantEstudiantes, contadorEstudiante = 0;
	static Scanner teclado = new Scanner(System.in);
	
	//INTENTO MOSTRAR TODOS LOS ESTUDIANTES GUARDADOS
	public static void mostrarEstudiantes() {
		System.out.println("\nESTUDIANTES:\n");
		for(int i = 0; i<cantEstudiantes; i++) {
			System.out.println(estudiantes[i]);
			estudiantes[i].mostrarNotas();
		}
	}
	
	
	/**
	 * Metodo para mostrar las materias anteriormente creadas, las cuales son para todos los
	 * estudiantes
	 */
	public static void mostrarMaterias() {
		System.out.println("\nMATERIAS:\n");
		for(int i=0;i<materias.length; i++) {
			System.out.print(materias[i]+"   ");
		}
		System.out.println("");
	}
	
	/**
	 * Metodo donde se muestra la matriz del estudiante creado
	 * @param estu Objeto estudiante para usar los metodos que muestran su informacion
	 */
	public static void mostrarDatosEstudiante(Estudiante estu) {
		System.out.println("\nDatos Del Estudiante Creado");
		System.out.println(estu.toString()); //Metodo to String del objeto para mostrar nombre e id del estudiante
		estu.mostrarNotas(); //Metodo mostrar notas del objeto para mostrar las notas y promedio del estudiante
		System.out.println("\n\n");
	}
	
	
	/**
	 * Metodo donde se completa la matriz, agregandole las notas y sus respectivos promedios
	 */
	public static void agregarNotas() {
		int contMat =0, contNot = 1;
		double nota, promedio=0;
		
		//Ciclo para recorrer todas las columnas y poder agregar en cada una la nota, un espacio o el promedio
		for(int i=0; i<matriz[0].length; i++) {
			
			if(i==0) { //Si estan en la columna 0 poner un salto de linea debido a que ahi va el titulo de la materia
				matriz[1][i] = "\t";
			}else if(i!=0 && (i%(2+cantNotas))==0) { //Si estan en una casilla donde este el titulo de alguna materia poner un espacio debido a que ahi no va nota
				matriz[1][i] = "\t";
				contMat++;
			}else if(((i+1)%(2+cantNotas))==0){ //Si estan en la casilla del titulo "promedio" se agrega el promedio que se calculo en el ciclo
				promedio /= cantNotas; //Se calcula el promedio
				matriz[1][i] = String.valueOf(promedio+"\t");//Se agrega el promedio volviendolo String
				promedio=0;
				contNot = 1;
			}else { //Si estan en la casilla normal se pedira la nota y se agregara a la matriz
				System.out.println("Digite la nota "+contNot+" de la materia "+materias[contMat]);
				nota = teclado.nextDouble(); 
				promedio+=nota; //Se va sumando las notas para luego hallar el promedio
				matriz[1][i] = String.valueOf(nota+"\t"); //Se agrega la nota volviendolo String
				contNot++;
			}
		}
	}
	/**
	 * Metodo que permite crear un objeto estudiante donde se le asignara el id, nombre y materias
	 */
	public static void crearEstudiante() {
		//Se le pide el id del nuevo estudiante
		System.out.println("Digite el id del estudiante");
		String id = teclado.next();
		//Se le pide el nombre del nuevo estudiante
		System.out.println("Digite el nombre del estudiante");
		String nombre = teclado.next();
		//Se lleva al metodo agregar notas
		agregarNotas();
		/*Se crea el objeto Estudiante donde se le agrega la matriz creada con las notas y promedios
		  Y el nombre y el id del estudiante*/
		Estudiante estu = new Estudiante(matriz, nombre, id);
		//Se va al metodo mostrar Datos Estudiante
		mostrarDatosEstudiante(estu);
		crearMatriz();
		/*Condicion para agregar el nuevo estudiante a la lista de estudiantes en el caso que
		  aun haya espacio para este nuevo estudiante*/
		if(contadorEstudiante<cantEstudiantes) {
			estudiantes[contadorEstudiante] = estu;
			contadorEstudiante++; //Se aumenta el contador para agregar futuramente un nuevo estudiante
			
		}else {
			System.out.println("Ya no se pueden agregar mas estudiantes");
		}
		
	}
	
	/**
	 * Metodo que contiene el menu donde el usuario puede digitar la opcion que desee
	 */
	public static void menu() {
		System.out.println("\n\nDigite\n");
		System.out.println("1) Agregar notas nuevo estudiante");
		System.out.println("2) Mostrar Materias");
		System.out.println("3) Mostrar Estudiantes");
		System.out.println("0) Salir");
		
		int men = teclado.nextInt();
		switch(men) {
		
			//Opcion para crear un estudiante con sus notas y promedios
			case 1:
				crearEstudiante();//Lo lleva al metodo crear Estudiante
			break;
			
			//Opcion para mostrar las materias de cada estudiante
			case 2:
				mostrarMaterias();
			break;	
			
			//Opcion para mostrar todos los estudiantes con notas y promedios
			case 3:
				mostrarEstudiantes();
			break;	
			
		
			case 0:
				System.out.println("\n\nCerrando programa");
				System.exit(0);
			break;
		
			default:
				System.out.println("Digito un valor incorrecto, intentelo de nuevo");
			break;	
		}
		menu();
	}
		
	/**
	 * Metodo que crea la matriz principal que va a tener cada estudiante (es decir la que contiene
	 * las materias, las notas y las definitivas, solo se crea lo que va a tener fijo en la matriz
	 * como el nombre de las columnas
	 */
	public static void crearMatriz() {
		/*Se crea la matriz con el tama�o de 2 filas (1 titulos, 2 notas) y el tama�o de columnas
		  es una operacion la cual deja los espacios de las notas para cada materia y tambien con
		  espacio para el promedio como el ejemplo de la linea 6*/
		matriz = new String[2][(2+cantNotas)*cantMaterias];
		int contMat =0, contNot = 1;
		//Ciclo para recorrer todas las columnas y asignarle algo en especifico ya sea un titulo o no
		for(int i=0; i<matriz[0].length; i++) {
			//Poner la primera materia en la posicion 0,0
			if(i==0) {
				matriz[0][i] = materias[contMat];
				contMat++;
				//Poner las otras materias cuando se cumpla la operacion
			}else if(i!=0 && (i%(2+cantNotas))==0) {
				matriz[0][i] = materias[contMat];
				contMat++;
				contNot = 1;
				//Poner titulo promedios
			}else if(contNot-1==cantNotas){
				matriz[0][i] = "Promedio\t";
				contNot++;
				
			}else {//Poner titulos de notas
				matriz[0][i] = " Nota"+contNot+"  ";
				contNot++;
			}
		}
	}
	
	/**
	 * Metodo que crea el arreglo materias con el tama�o anteriormente seleccionado
	 * para tener el nombre de todas las materias a usar
	 */
	public static void crearMaterias() {
		materias = new String[cantMaterias];//Se Crea el arreglo con el tama�o
		String nombreMateria; //Se crea una variable que posteriormente va a tener el nombre de la materia
		//Ciclo para guardar todas las materias que se digitaron que se ibana  agregar
		for (int i = 0; i < materias.length; i++) {
			System.out.println("Digite el nombre de la materia en la posicion ["+i+"]");
			nombreMateria = teclado.next();
			materias[i] = nombreMateria; //Se agregan las materias al arreglo "materias"
		}
		
	}
	
	/**
	 * Metodo Principal
	 */
	public static void main(String[] args) {
		System.out.println("PROGRAMA CONTROL DE NOTAS");
		//Se pregunta cuantas materias se van a usar en la matriz
		System.out.println("Digite cuantas materias quiere agregar");
		cantMaterias = teclado.nextInt();
		//Se pregunta cuantas notas va a tener cada materia
		System.out.println("Digite cuantas notas quiere que tenga cada materia");
		cantNotas = teclado.nextInt();
		//Se pregunta cuantos estudiantes va a tener el arreglo estudiantes
		System.out.println("Digite cuantos estudiantes va a agregar");
		cantEstudiantes = teclado.nextInt();
		//Se crea el arreglo estudiantes con el tama�o escogido anteriormente
		estudiantes = new Estudiante[cantEstudiantes];
		
		//Se va al metodo crear materias
		crearMaterias();
		//Se va al metodo crear matriz
		crearMatriz();
		//Se va al metodo menu
		menu();
	}
}
