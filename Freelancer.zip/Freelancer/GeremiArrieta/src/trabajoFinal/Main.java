package trabajoFinal;

import java.util.Scanner;

public class Main {
	//Variables y Scanner
	static Scanner teclado = new Scanner(System.in);
	static int  contPares=0, contImpares=0;

	//Muestra pares, impares y digitos del numero seleccionado
	public static void mostrarInfo(int numero, int digitos) {
		System.out.println("INFORMACION:");
		System.out.println("\nEl numero "+numero+" tiene:");
		System.out.println(digitos+" Digitos");
		System.out.println(contPares+" Numeros Pares");
		System.out.println(contImpares+ " Numeros Impares\n");
	}
	
	//Cuenta cuantos pares y cuantos impares hay
	public static void paresImpares(String aux) {
		for(int i=0; i<aux.length(); i++) {
			int auxInt = (int)aux.charAt(i);
			if(auxInt%2==0) {
				contPares++;
			}else {
				contImpares++;
			}
		}
	}
	
	//Donde se produce todos los metodos
	public static void procedimientos() {
		int salir=0, numero, digitos;//Variables
		String aux;
		do {
			//Se guarda el numero
			System.out.println("Digite el numero para dar informacion de este");
			numero = teclado.nextInt();
			//Se guarda en un String el numero convirtiendo el entero en una cadena
			aux = Integer.toString(numero);
			//Lo anterior para usar la funciond de cadenas length para saber el tama�o (digitos)
			digitos= aux.length();
			
			//Metodos para saber cantidad de pares e impares
			paresImpares(aux);
			//Muestra la informacion recolectada
			mostrarInfo(numero, digitos);
			
			//Opcion para salir o repetir
			System.out.println("�Desea salir del codigo? \n1)Si, Salir \nOtro Valor)No, Volver a repetir");
			int opcion = teclado.nextInt();
			
			if(opcion==1) {
				System.out.println("ADIOS");
				salir++;
			}
			
		}while(salir==0);
	}
	
	//MAIN
	public static void main(String[] args) {
		System.out.println("Ejercicio que pide numero positivo y dar informacion de este\n");
		procedimientos();
	}
}
