//Parcial hecho por: Carlos Jimenez Valdelomar
import java.util.ArrayList;
import java.util.Scanner;
/*
  Crear una aplicaci�n que permita tener seguridad de Usuario y Password, al 
  inicio de la aplicaci�n debe solicitar crearlos. Y Controlar Password al 
  digitar mal la palabra clave no permita hacer los ejercicios
*/

public class CarlosJumenezParcialIII {

	static Scanner teclado = new Scanner(System.in);// Escanner para recibir los datos digitados por teclado
	static ArrayList<String[]> usuarios = new ArrayList<String[]>();// Array List que contiene todos los usuarios y sus
	static String usuario, password;//Variables donde se guardan el usuario y password														// contrase�as
	static int contador = 0; // Variables para controlar la cantidad de usuarios maximos a crear y el contador
	static boolean entra; // Variable para mas adelante permitir el ingreso y el registro

	/**
	 * Metodo para mostrar todos los usuarios registrados con su respectivo password
	 */
	public static void mostrarUsuarios() {
		System.out.println("\n\nUSUARIOS Y PASSWORD REGUSTRADAS:\n");
		for (int i = 0; i < contador; i++) { // Ciclo for para recorrer y mostrar los usuarios y passwords registradas
			System.out.println("Usuario: " + usuarios.get(i)[0] + "\tPassword: " + usuarios.get(i)[1] + "\n");
		}
	}

	/**
	 * Metodo para registrar un usuario nuevo
	 */
	public static void registrar() {
		String[] usu = new String[2];// Arreglo que guarda el usuario y contrase�a registrada
		
		System.out.println("\n\nREGISTRANDO USUARIO\n");
		System.out.println("Digite su Usuario");// Guarda el usuario en el arreglo posicion 0
		usu[0] = teclado.next();
		System.out.println("Digite su password");// Guarda el password en el arreglo posicion 1
		usu[1] = teclado.next();

		usuarios.add(usu);//Se adiciona al ArrayList el usuario creado en el arreglo 

		System.out.println("USUARIO REGISTRADO");//Mensaje de exito
		contador++;//Contador de usuarios creados aumenta para luego usarse en ciclos mas adelante
	}

	/**
	 * Metodo para validar y poder ingresar al usuario con su respectivo password
	 */
	public static void ingresar() {
		entra = false;//Variable booleana para controlar el ingreso y validacion

		System.out.println("\n\nINGRESANDO\n");
		
		System.out.println("Digite su Usuario");//Guarda el usuario que se quiere validar
		usuario = teclado.next();
		System.out.println("Digite su password");//Guarda la variable que se quiere validar
		password = teclado.next();

		for (int i = 0; i < contador; i++) {//Ciclo para validar el usuario y password digitados anteriormente
			if (usuarios.get(i)[0].equalsIgnoreCase(usuario)) {
				if (usuarios.get(i)[1].equalsIgnoreCase(password)) {
					entra = true;//La variable se vuelve "true" debido a que si existe el usuario y su contrase�a fue correcta
				}
			}
		}

		if (entra == true) {//Condicional para comprobar si fue exitoso el ingreso o no para mandar el respectivo mensaje
			System.out.println("INGRESADO CORRECTAMENTE! Hola " + usuario);
		} else {
			System.out.println("Usuario o Password Incorrecta");
		}

	}

	/**
	 * Metodo Principal del programa
	 */
	public static void main(String[] args) {

		int opc;//Variable para el menu
		String respuesta;// Variable para repetir de nuevo el programa
		System.out.println("�USUARIO Y PASSWORD!\n");

		do { // Ciclo repetitivo para que sea posible repetir el programa
				// MENU con las opciones a escoger
			System.out.println("\n\nMENU:\n");
			System.out.println("1. Registrar");
			System.out.println("2. Ingresar");
			System.out.println("3. Ver usuarios y passwords creadas");
			System.out.println("0. Salir");
			System.out.println("Digite que desea realizar? ");
			System.out.print("Opcion: ");
			opc = teclado.nextInt();

			// Switch para que el programa pueda ir por diferentes caminos dependiendo que
			// opcion haya digito por teclado en el menu
			switch (opc) {

			case 0:// Caso 0 para Cerrar el programa
				System.out.println("\n\n\nCERRANDO EL PROGRAMA!");
				System.exit(0);// Cierra el programa
				break;

			case 1:// Caso 1 para registrar Usuario
				registrar();
				break;

			case 2:// Caso 2 para Ingresar
				ingresar();
				break;

			case 3:// Caso 3 para Mostrar los usuarios creados
				mostrarUsuarios();
				break;

			default:// Caso Default para cuando se digite por teclado una opcion que no se las del
					// menu
				System.out.println("\n\nDIGITO UN VALOR INVALIDO INTENTELO DE NUEVO");
				break;
			}

			// Opcion para repetir el programa de nuevo
			System.out.println("\nQuiere repetir el programa? s/n");
			respuesta = teclado.next();
		} while (respuesta.equals("s") || respuesta.equals("S"));

		System.out.println("\n\n\nCERRANDO EL PROGRAMA!");
	}
}
