package actividadesJineteCaballo;

import java.util.Scanner;

public class Actividades {
	
	public static void TransportarEnCaballo() {
		System.out.println("\n\n\t\t\tEL JINETE SE HA TRANSPORTADO EN EL CABALLO!!\n\n");
	}
	
	public static void LavarCaballo() {
		System.out.println("\n\n\t\t\tEL JINETE HA LAVADO AL CABALLO!!\n\n");
	}
	
	public static void EntrenarCaballo() {
		System.out.println("\n\n\t\t\tEL JINETE HA ENTRENADO AL CABALLO!!\n\n");
	}
	
	public static void AlimentarCaballo() {
		System.out.println("\n\n\t\t\tEL JINETE HA ALIMENTADO AL CABALLO!!\n\n");
	}
	
	public static void menu() {
		Scanner leer = new Scanner(System.in);
		System.out.println("\n\t\t\t\tMENU\n");
		System.out.println("\t\t\t1. Alimentar al Caballo");
		System.out.println("\t\t\t2. Entrenar al Caballo");
		System.out.println("\t\t\t3. Lavar al Caballo");
		System.out.println("\t\t\t4. Transportarse en el Caballo");
		System.out.println("\t\t\t0. Salir");
		System.out.print("\t\t\tDigite la opcion que desea:");
		
		int opc = leer.nextInt();
		
		switch(opc) {
			case 1:
				AlimentarCaballo();
			break;
			
			case 2:
				EntrenarCaballo();
			break;
				
			case 3:
				LavarCaballo();
			break;	
			
			case 4:
				TransportarEnCaballo();
			break;
				
			case 0:
				System.out.println("\n\n\t\t\t\tMUCHAS GRACIAS");
				System.exit(0);
			break;
				
			default:
				System.out.println("\n\n\t\t\t\tHA DIGITADO UN VALOR INVALIDO, INTENTE DE NUEVO");
			break;
		}
		menu();
	}
	
	public static void main(String[] args) {
		System.out.println("\n\n\t\tEJERCICIO ACTIVIDADES CABALLO JINETE");
		menu();
	}
}
