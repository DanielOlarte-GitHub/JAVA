package nreinas;

/**
 * EJERCICIO DE LAS NREINAS: SE QUIERE SABER TODAS LAS POSIBLES SOLUCIONES DE
 * QUE LAS 8 REINAS DEL AJEDREZ ESTEN EN EL TABLERO (8X8) SIN QUE HAYA PROBLEMA
 * ENTRE ESTA
 *
 * RECORDAMOS QUE LAS REINAS SEGUN EL JUEGO DE AJEDREZ, PUEDE ATACAR DE FORMA
 * VERTICAL, HORIZONTAL Y VERTICAL
 *
 * El ejercicio esta fijo para 8x8 simulando el caso original de las NReinas de
 * un tablero normal de ajedrez, y con 8 reinas que es la cantidad de peones que
 * pueden convertirse en las reinas
 *
 * Se simula la reina a traves de una R en los campos donde se van mostrando, en
 * la cual todas las soluciones tiene la cantidad de 8 reinas, soluciones las
 * cuales ninguna reina se puede atacar entre ellas, EJERCICIO NREINAS
 *
 * Se hallo una cantidad de 92 Soluciones posibles.
 *
 */
public class NReinas {

    static int contador = 1;

    public static void main(String[] args) {

        String[][] tablero = new String[8][8];

        generarTablero(tablero);
        ubicarReina(tablero, 0);

    }

    //Se pone en cada posicion de la matriz un espacio vacio Generando el tablero
    public static void generarTablero(String tablero[][]) {

        for (int i = 0; i < tablero.length; i++) {
            for (int j = 0; j < tablero.length; j++) {
                tablero[i][j] = "     ";
            }
        }
    }

    //METODO CON EL BACKTRACKING
    //Agrega la reina (R) al tablero, se agregan las reinas por columnas de izquierda a derecha
    public static void ubicarReina(String[][] tablero, int columna) {
        //For para recorrer todas las filas
        for (int fila = 0; fila < tablero.length; fila++) {
            //Si cumple los requisitos se coloca la reina (si no queda en conflicto con otra reina)
            if (isValido(tablero, fila, columna)) {
                tablero[fila][columna] = "  R  ";
                //Si aun quedan mas columnas para colocar reinas, se repite el proceso
                if (columna < tablero.length - 1) {
                    ubicarReina(tablero, (columna + 1));
                } else {//Si ya se acabaron las columnas(si ya no se van a agregar mas reinas) se imprime la solucion
                    imprimirMatriz(tablero);
                }

                //BACKTRACKING
                //Se ponen espacios vacios en las casillas del tablero que ya se revisaron (donde no esta ubicada la reina)
                tablero[fila][columna] = "     ";
            }
        }

    }

    //Revisa las posiciones del tablero para comprobar si es fiables poner la reina y que no haya una restriccion
    public static boolean isValido(String[][] tablero, int fila, int columna) {

        //Comprobacion de que no haya un Reina en la misma columna hacia abajo
        for (int i = 0; i < columna; i++) {
            if (tablero[fila][i].equals("  R  ")) {
                return false;
            }
        }

        //Comprobacion de que no haya una Reina en la diagonal superior izquierda
        for (int i = 0; (fila - i) >= 0 && (columna - i) >= 0 && i < tablero.length; i++) {

            if (tablero[fila - i][columna - i].equals("  R  ")) {
                return false;
            }

        }

        //Comprobacion de que no haya una Reina en la diagonal inferior izquierrda
        for (int i = 0; (fila + i) < tablero.length && (columna - i) >= 0 && i < tablero.length; i++) {

            if (tablero[fila + i][columna - i].equalsIgnoreCase("  R  ")) {
                return false;
            }
        }

        return true;
    }

    //IMPRIME LAS SOLUCIONES
    public static void imprimirMatriz(String[][] tablero) {

        System.out.println("\n\n\t\t\t\tSOLUCION NUMERO: " + contador + " / 92\n");
        contador++;

        System.out.println("\n\t\t-------------------------------------------------");
        for (int i = 0; i < tablero.length; i++) {
            System.out.print("\t\t|");
            for (int j = 0; j < tablero.length; j++) {
                System.out.print(tablero[i][j] + "|");
            }
            System.out.println("\n\t\t-------------------------------------------------");
        }
        System.out.println("\n\n- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - ");

    }
}
