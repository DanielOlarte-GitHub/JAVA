package candidatoVotar;

import java.util.Scanner;

public class Codigo {
	//Se crean las variables que se van a usar en todo el programa
	static String nombre, id;
	//Se crea el scanner para leer lo que el usuario va a digitar por teclado
	static Scanner teclado = new Scanner(System.in);
	
	//Metodo si la eleccion del usuario es el candidato C
	public static void candidatoC(String color) {
		System.out.println("\n\n\n\t\tUsted ha votado por el partido "+color+ " candidato C");
	}
	
	//Metodo si la eleccion del usuario es el candidato B
	public static void candidatoB(String color) {
		System.out.println("\n\n\n\t\tUsted ha votado por el partido "+color+ " candidato B");
	}
	
	//Metodo si la eleccion del usuario es el candidato A
	public static void candidatoA(String color) {
		System.out.println("\n\n\n\t\tUsted ha votado por el partido "+color+ " candidato A");
	}

	//Metodo que manda a otro metodo segun la eleccion del usuario
	public static void eleccion(int opc) {
		String color; //Variable que guarda el color del partido que escogio el usuario
		//Switch que hace procesos segun el candidato escodigo, guarda el color del partido
		//manda al metodo seleccionado, agradece al usuario y se sale del codigo
		switch (opc) {
			case 1:
				color="ROJO";
				candidatoA(color);
				System.out.println("\n\n\n\t\tGRACIAS " + nombre + " POR VOTAR EN LAS ELECCIONES 2021");
				System.exit(0);
			break;

			case 2:
				color="VERDE";
				candidatoB(color);
				System.out.println("\n\n\n\t\tGRACIAS " + nombre + " POR VOTAR EN LAS ELECCIONES 2021");
				System.exit(0);
			break;

			case 3:
				color="AZUL";
				candidatoC(color);
				System.out.println("\n\n\n\t\tGRACIAS " + nombre + " POR VOTAR EN LAS ELECCIONES 2021\n\n");
				System.exit(0);
			break;

			case 0:
				System.out.println("\n\n\n\t\tCERRANDO PROGRAMA");
				System.exit(0);
			break;

			default:
				System.out.println("\n\t\tDigito un valor Incorrecto, intentelo de nuevo");
			break;
		}
		menu();
	}

	//Metodo que imprime el menu
	public static void menu() {
		int opc;
		System.out.println("\n\n-------------------------------------------------------------");
		System.out.println("\n\t\tESCOJA POR CUAL CANDIDATO QUIERE VOTAR\n");
		System.out.println("\t\t1) CANDIDATO A: PARTIDO ROJO");
		System.out.println("\t\t2) CANDIDATO B: PARTIDO VERDE");
		System.out.println("\t\t3) CANDIDATO C: PARTIDO AZUL");
		System.out.println("\t\t0) CERRAR EL PROGRAMA");
		System.out.print("\t\tEscoja la opcion que desee (0-3): ");
		opc = teclado.nextInt();
		System.out.println("\n-------------------------------------------------------------");
		eleccion(opc);
	}

	//Metodo principal 
	public static void main(String[] args) {
		System.out.println("\n\n\t\tELECCIONES PRESIDENCIALES 2021\n\n");
		System.out.print("\t\tDIGITE SU ID: ");
		id = teclado.nextLine();
		System.out.print("\t\tDIGITE SU NOMBRE: ");
		nombre = teclado.nextLine();
		menu();
	}
}
