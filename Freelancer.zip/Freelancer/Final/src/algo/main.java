package algo;
//Parcial grupo 03
//Integrantes
// Marco Pe�a
// �scar Quesada
// Saulo Viquez

//Librerias utilizadas
import java.util.Scanner;
/**
 * Ejercicio 3: Solicita 2 numeros; a y b
 * Imprime todos los numeros primos entre a y b incluidos
 * Hacer la suma de todos los numeros entre a y b inclusive
 * Calcular el Factorial del resultado de la suma entre a y b
 * Imprime en pantalla los resultados
 */

/**
 * Clase main inicial que ejecuta las instrucciones y metodos
 * necesarias para resolver el problema
*/
public class main {
	//Metodo main inicial
	public static void main(String[] args) {
		//Variables de la clase 
		int num_a;
		int num_b;
		boolean exit = false;
		Scanner read = new Scanner(System.in);
		System.out.print("Bienvenido al programa.\n");
		while(!exit) {
			//inicio del programa
			System.out.print("Para continuar...\n");
			System.out.print("Por favor digite numeros enteros positivos.\n");
			System.out.print("A continuacion digite el primer numero.\n");
			num_a = read.nextInt();
			System.out.print("Ahora digite el segundo numero.\n");
			num_b = read.nextInt();
			
			//Oredena los numeros para que num_a sea el menor
			if(num_a>num_b) {
				int a = num_a;
				num_a = num_b;
				num_b = a;
			}
			
			//Llama a los metodos
			Primos(num_a,num_b);
			Suma(num_a,num_b);
			
			//Verifica si el usuario desea salir del programa
			System.out.print("Digite 1 si desea continuar.\n");
			if(read.nextInt() != 1) {
				exit = true;
				System.out.print("El programa finalizo.\n");
			}
		}
	}
	
	//Metodo Primos que calcula los primos entre a y b
	public static void Primos(int num_a, int num_b) {
		System.out.print("Los numeros primos entre ");
		System.out.print(num_a);
		System.out.print(" y ");
		System.out.print(num_b);
		System.out.print(" son: \n");
		for(int i = num_a; i<=num_b; i++ ) {
			boolean primo = true;
			for(int j = 2; j<i; j++ ) {
				if(i%j==0) {
					primo = false;
				}
			}
			if(primo) {
				System.out.print(i);
				System.out.print("\n");
			}
		}
		
	}
	
	//Metodo Suma que suma los numeros entre a y b
	public static void Suma(int num_a, int num_b) {
		System.out.print("La suma entre los numeros elegidos es de: \n");
		int suma = 0;
		for(int i = num_a; i<=num_b; i++ ) {
			suma += i;
		}
		System.out.print(suma);
		System.out.print("\n");
		
		//Se llama al metodo Factorial
		Factorial(suma);
	}
	
	// Metododo Factorial que calcula el factorial de la suma
	// de a y b.
	public static void Factorial(int num) {
		System.out.print("El factorial de la suma entre los numeros es de: \n");
		// Se utiliza double para el factorial ya que es el unico capaz de almacenar 
		// datos tan extensos.
		double factorial = 1;
		while ( num!=0) {
			 factorial=factorial*num; 
			 num--;
			}
		System.out.print(factorial);
		System.out.print("\n");
	}
}

