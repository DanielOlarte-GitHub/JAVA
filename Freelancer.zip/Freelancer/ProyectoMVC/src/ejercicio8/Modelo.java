package ejercicio8;

public class Modelo {
	String nombreEstudiante;
	String nombreMateria;
	int idEstudiante;
	double nota;
	double promedio;
	
	public Modelo() {
		
	}
	
	public Modelo(String nombreEstudiante, String nombreMateria, double nota, double promedio, int idEstudiante) {
		
		this.nombreEstudiante = nombreEstudiante;
		this.nombreMateria = nombreMateria;
		this.nota = nota;
		this.promedio = promedio;
		this.idEstudiante = idEstudiante;
	}

	public String getNombreEstudiante() {
		return nombreEstudiante;
	}

	public void setNombreEstudiante(String nombreEstudiante) {
		this.nombreEstudiante = nombreEstudiante;
	}

	public String getNombreMateria() {
		return nombreMateria;
	}

	public void setNombreMateria(String nombreMateria) {
		this.nombreMateria = nombreMateria;
	}

	public double getNota() {
		return nota;
	}

	public void setNota(double nota) {
		this.nota = nota;
	}

	public double getPromedio() {
		return promedio;
	}

	public void setPromedio(double promedio) {
		this.promedio = promedio;
	}

	public int getIdEstudiante() {
		return idEstudiante;
	}

	public void setIdEstudiante(int idEstudiante) {
		this.idEstudiante = idEstudiante;
	}
		
	
}
