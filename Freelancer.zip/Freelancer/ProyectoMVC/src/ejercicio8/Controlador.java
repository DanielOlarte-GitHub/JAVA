package ejercicio8;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DecimalFormat;

public class Controlador {
	BufferedReader sc = new BufferedReader(new InputStreamReader(System.in));
	int cantEstudiantes, cantMaterias;
	DecimalFormat formatoDecimales = new DecimalFormat("#.00"); //Limita los decimales en 2 decimas
	
	String[][] estudiantes;
	public Controlador() throws NumberFormatException, IOException {
		System.out.println("Digite con cuantos estudiantes desea trabajar");
		cantEstudiantes = Integer.parseInt(sc.readLine());
		System.out.println("Digite con cuantas materias desea trabajar");
		cantMaterias = Integer.parseInt(sc.readLine());
		estudiantes = new String[cantMaterias+2][cantEstudiantes+2];
		
		//Vacias la matriz
		for(int i=0; i<estudiantes.length; i++) {
			for(int j=0; j<estudiantes[0].length; j++) {
				estudiantes[i][j] = "";
			}
		}
		
		estudiantes[0][0] = "CODIGO DE MATERIAS";
		estudiantes[0][2] = "CODIGO DE ESTUDIANTES";
		estudiantes[1][0] = "              ";
		

    }
	
	public void agregarMaterias() throws IOException {
		Modelo nuevo = new Modelo();
		String nombre;
		for(int i = 2; i<estudiantes.length; i++) {
			System.out.println("\nDigite el nombre de la materia #"+(i-1));
			nombre = sc.readLine();
			nuevo.setNombreMateria(nombre);
			estudiantes[i][1] = "  "+(i-2);
			estudiantes[i][0] = "   "+nuevo.getNombreMateria();
		}
	}
	
	public void agregarEstudiantes() throws IOException {
		Modelo nuevo = new Modelo();
		String nombre, id;
		for(int i = 2; i<estudiantes[0].length; i++) {
			System.out.println("\nDigite el nombre del estudiante #"+(i-1));
			nombre = sc.readLine();
			nuevo.setNombreEstudiante(nombre);
			System.out.println("Digite el id de "+nombre);
			id = sc.readLine();
			nuevo.setIdEstudiante(Integer.parseInt(id));
			estudiantes[1][i] = nuevo.getIdEstudiante()+"";
			
		}
	}
	
	public void agregarNotas() throws IOException {
		Modelo nuevo = new Modelo();
		System.out.println("Digite con cuantas notas va a trabajar cada materia");
		int cantNotas = Integer.parseInt(sc.readLine());
		double notas, suma=0;
		String promedio;
		
		for(int i=2; i<estudiantes.length; i++) {
			for(int j=2; j<estudiantes[0].length; j++) {
				for(int k=0; k<cantNotas; k++) {
					System.out.println("\nDigite la nota numero "+(k+1)+" de "+estudiantes[i][0] + " del estudiante con id "+estudiantes[1][j]);
					notas = Double.parseDouble(sc.readLine());
					suma += notas;
				}
				nuevo.setNota(suma);
				promedio = (suma / cantNotas)+"";
				nuevo.setPromedio(Double.parseDouble(promedio));
				estudiantes[i][j] = nuevo.getPromedio()+"";
				
				suma = 0;
			}
		}
	}
	
	public void imprimir() {
		System.out.println("------------------------------------------------------------------------");
		System.out.println("|"+estudiantes[0][0]+ "     |       "+estudiantes[0][2]);
		System.out.println("|-----------------------|-----------------------------------------------");
		for(int i=1; i<estudiantes.length; i++) {
			for(int j=0; j<estudiantes[0].length; j++) {
				if(estudiantes[i][j]!="") {
					System.out.print("|");
				}
				if(i>=2) {
					if(j>=2) {
						System.out.print(formatoDecimales.format(Double.parseDouble(estudiantes[i][j]))+"\t");
					}else {
						System.out.print(estudiantes[i][j]+"\t");
					}
				}else {
					System.out.print(estudiantes[i][j]+"\t");
				}
				
				
			}
			System.out.print(" |\n");
		}
		System.out.println("------------------------------------------------------------------------");
	}
}
