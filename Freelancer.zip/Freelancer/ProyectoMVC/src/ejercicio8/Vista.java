package ejercicio8;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Vista {
	public static void main(String[] args) throws IOException {

		BufferedReader sc = new BufferedReader(new InputStreamReader(System.in));
		Controlador con = new Controlador();
		// Variables
		int opcion = 1;
		
		while (opcion >= 1 && opcion <= 6) {
			System.out.println("\n\n");
			System.out.println("Universidad ECCI");
			System.out.println("Materias y notas de estudiantes");
			System.out.println("Seleccione tarea a realizar:");
			System.out.println("1. Ingresar Materias");
			System.out.println("2. Ingresar Estudiantes");
			System.out.println("3. Agregar notas");
			System.out.println("4. Imprimir Tabla");
			System.out.println("0. Salir");
			System.out.println("Digite la Opcion:");
			opcion = Integer.parseInt(sc.readLine());
			switch (opcion) {
				case 1:
					System.out.println("\n\nINGRESAR MATERIAS");
					con.agregarMaterias();
				break;
				
				case 2:
					System.out.println("\n\nINGRESAR ESTUDIANTES");
					con.agregarEstudiantes();
				break;
	
				case 3:
					System.out.println("\n\nINGRESAR NOTAS");
					con.agregarNotas();
				break;
				
				case 4:
					System.out.println("\n\nIMPRIMIENDO TABLA DE DATOS\n");
					con.imprimir();
				break;
	
				case 0:
					// SALIR
					System.out.println("Hasta Pronto");
					System.exit(0);
	
				default:
					System.out.println("Opcion no valida");
				}
	
			}

	}
}
