package ejercicio9;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DecimalFormat;


public class Controlador {
	BufferedReader sc = new BufferedReader(new InputStreamReader(System.in));
	DecimalFormat formatoDecimales = new DecimalFormat("#.00"); //Limita los decimales en 2 decimas
	
	int cantEmpleados;
	String[][] nomina;
	String[][] tablaDeducido;
	public Controlador() throws NumberFormatException, IOException {
		System.out.println("Digite con cuantos empleados desea trabajar");
		cantEmpleados = Integer.parseInt(sc.readLine());
		nomina = new String[cantEmpleados+2][11];
		tablaDeducido = new String[cantEmpleados+2][7];
		
		//Vacias las matrices
		for(int i=0; i<nomina.length; i++) {
			for(int j=0; j<nomina[0].length; j++) {
				nomina[i][j] = "";
			}
		}
		for(int i=0; i<tablaDeducido.length; i++) {
			for(int j=0; j<tablaDeducido[0].length; j++) {
				tablaDeducido[i][j] = "";
			}
		}
		
		
		//NOMINA DATOS FIJOS
		nomina[0][0] = "CEDULA";
		nomina[0][1] = "NOMBRE";
		nomina[0][2] = "SALARIO";
		nomina[0][3] = "AUXILIO TRANSPORTE";
		nomina[0][4] = "DIAS";
		nomina[0][5] = "TOTAL DEVENGADO";
		nomina[1][5] = "SUELDO";
		nomina[1][6] = "HORAS EXTRAS DIUR";
		nomina[1][7] = "HORAS EXTRAS NOCT";
		nomina[1][8] = "HORAS EXTRAS FEST";
		nomina[1][9] = "RECARGO NOCT";
		nomina[1][10] = "TOT DEVENGADO";
		
		
		//TABLA DEDUCIDO DATOS FIJOS
		tablaDeducido[0][2] = "TOTAL DEDUCIDO";
		tablaDeducido[1][0] = "CEDULA";
		tablaDeducido[1][1] = "SALUD";
		tablaDeducido[1][2] = "PENSION";
		tablaDeducido[1][3] = "PRESTAMO";
		tablaDeducido[1][4] = "FONDO SOLIDARIDAD";
		tablaDeducido[1][5] = "TOTAL DEDUCIDO";
		tablaDeducido[1][6] = "NETO PAGADO";
		

    }
	
	public void llenarNomina() throws IOException {
		
		String cedula, nombre;
		double salario=0, auxilioTransporte=0, dias=0, sueldo=0, horasExDiurnas=0, horasExNocturnas=0, horasExFestivos=0, recargoNocturno=0, totalDevengado=0;
		double valorHora=0;
		for(int i = 2; i<nomina.length; i++) {
			Modelo nuevo = new Modelo();
			valorHora = 0;
			//NOMBRE
			System.out.println("\nDigite el nombre del empleado #"+(i-1));
			nombre = sc.readLine();
			nuevo.setNombre(nombre);
			//CEDULA
			System.out.println("\nDigite la cedula de "+nuevo.getNombre());
			cedula = sc.readLine();
			nuevo.setCedula(cedula);
			//SALARIO
			System.out.println("\nDigite el Salario de "+nuevo.getNombre());
			salario = Double.parseDouble(sc.readLine());
			nuevo.setSalario(salario);
			valorHora = salario/240; //240 horas que se trabaja al mes
			//AUXILIO TRANSPORTE SOLO A LOS QUE GANEN MENOS DE 2 SALARIOS MINIMOS (908526*2)

			if(salario <1817052) {
				auxilioTransporte = 106454;
			}
			nuevo.setAuxilioTransporte(auxilioTransporte);
			//DIAS
			System.out.println("\nDigite los dias Trabajados de "+nuevo.getNombre());
			dias = Double.parseDouble(sc.readLine());
			nuevo.setDias(dias);
			//SUELDO deberia ser con Horas no con Dias, deberia ser salario*horas / 240
			sueldo = (salario*dias)/30;
			nuevo.setSueldo(sueldo);
			//HORAS EXTRAS DIURNAS 0.25%
			System.out.println("\nDigite las horas extra diurnas de "+nuevo.getNombre());
			horasExDiurnas = Double.parseDouble(sc.readLine());
			nuevo.setHorasExDiurnas(horasExDiurnas);
			horasExDiurnas = ((valorHora*horasExDiurnas)*0.25);
			//HORAS EXTRAS NOCTURNAS 0.75%
			System.out.println("\nDigite las horas extra nocturnas de "+nuevo.getNombre());
			horasExNocturnas = Double.parseDouble(sc.readLine());
			nuevo.setHorasExNocturnas(horasExNocturnas);
			horasExNocturnas = ((valorHora*horasExNocturnas)*0.75);
			//HORAS EXTRAS FESTIVAS 0.75%
			System.out.println("\nDigite las horas extra festivas de "+nuevo.getNombre());
			horasExFestivos = Double.parseDouble(sc.readLine());
			nuevo.setHorasExFestivos(horasExFestivos);
			horasExFestivos = ((valorHora*horasExFestivos)*0.75);
			//RECARGO NOCTURNO 0.35%
			System.out.println("\nDigite las horas de recargo nocturno de "+nuevo.getNombre());
			recargoNocturno = Double.parseDouble(sc.readLine());
			nuevo.setRecargoNocturno(recargoNocturno);
			recargoNocturno = recargoNocturno+(recargoNocturno*0.35);
			//TOTAL DEVENGADO
			totalDevengado = recargoNocturno+horasExFestivos+horasExNocturnas+ horasExDiurnas+ sueldo+ auxilioTransporte;
			nuevo.setTotalDevengado(totalDevengado);
			
			
			nomina[i][0] = nuevo.getCedula();
			nomina[i][1] = nuevo.getNombre();
			nomina[i][2] = nuevo.getSalario()+"";
			nomina[i][3] = nuevo.getAuxilioTransporte()+"";
			nomina[i][4] = nuevo.getDias()+"";
			nomina[i][5] = nuevo.getSueldo()+"";
			nomina[i][6] = nuevo.getHorasExDiurnas()+"";
			nomina[i][7] = nuevo.getHorasExNocturnas()+"";
			nomina[i][8] = nuevo.getHorasExFestivos()+"";
			nomina[i][9] = nuevo.getRecargoNocturno()+"";
			nomina[i][10] = nuevo.getTotalDevengado()+"";
			
			System.out.println("NOMINA TERMINADA");
			llenarTotalDeducido(i, nuevo);
		}
	}
	
	public void llenarTotalDeducido(int i, Modelo nuevo) throws IOException {
		System.out.println("\nTABLA DE TOTAL DEDUCIDO");
		//CEDULA
		tablaDeducido[i][0] = nuevo.getCedula();
		//SALUD 4%
		tablaDeducido[i][1] = (nuevo.getTotalDevengado()*0.04)+"";
		nuevo.setSalud(nuevo.getTotalDevengado()*0.04);
		//PENSION 4%
		tablaDeducido[i][2] = (nuevo.getTotalDevengado()*0.04)+"";
		nuevo.setPension(nuevo.getTotalDevengado()*0.04);
		//PRESTAMO
		System.out.println("Digite su Cuota mensual de Prestamo (cuanto paga al mes por prestamo)");
		double prestamo = Double.parseDouble(sc.readLine());
		tablaDeducido[i][3] = prestamo+"";
		nuevo.setPrestamo(prestamo);
		//FONDO SOLIDARIDAD 1% A LOS QUE GANEN MAS DE 4 SALARIOS MINIMOS 908526*4
		if(nuevo.getTotalDevengado()> 3634104) {
			tablaDeducido[i][4] = (nuevo.getTotalDevengado()*0.01)+"";
			nuevo.setFondoSolidaridad(nuevo.getTotalDevengado()*0.01);
		}else {
			tablaDeducido[i][4] = 0+"";
			nuevo.setFondoSolidaridad(0);
		}
		//TOTAL DEDUCIDO
		double totalDeducido = nuevo.getFondoSolidaridad() + nuevo.getPrestamo() + nuevo.getPension() + nuevo.getSalud();
		tablaDeducido[i][5] = totalDeducido+"";
		nuevo.setTotalDeducido(totalDeducido);
		//NETO  PAGADO
		double netoPagado = nuevo.getTotalDevengado() - nuevo.getTotalDeducido();
		tablaDeducido[i][6] = netoPagado+"";
		
	}
	
	
	public void imprimirNomina() {
		System.out.println("\nIMPRIMIENDO PRIMERA PARTE DE LA NOMINA");
		System.out.println("\n------------------------------------------------------------------------------------------------");
		System.out.println("|"+nomina[0][0]+"\t|"+nomina[0][1]+"\t|"+nomina[0][2]+"\t|"+nomina[0][3]+"| "+nomina[0][4]+" |");
		
		for(int i=2; i<nomina.length; i++) {
			for(int j=0; j<=4; j++) {
				if(nomina[i][j]!="") {
					System.out.print("|");
				}
				
				System.out.print(nomina[i][j]+"\t");
				
				
				
			}
			System.out.print(" |\n");
		}
		System.out.println("------------------------------------------------------------------------------------------------");
		
		
		//SEGUNDA PARTE
		System.out.println("\n\n\nIMPRIMIENDO SEGUNDA PARTE DE LA NOMINA");
		System.out.println("\n------------------------------------------------------------------------------------------------");
		System.out.println("|                          "+nomina[0][5]);
		System.out.println("|"+nomina[1][5]+"\t\t|"+nomina[1][6]+"|"+nomina[1][7]+"|"+nomina[1][8]+"|"+nomina[1][9]+"|"+nomina[1][10]+"|");
		
		for(int i=2; i<nomina.length; i++) {
			for(int j=5; j<nomina[0].length; j++) {
				if(nomina[i][j]!="") {
					System.out.print("|");
				}
				if(j==5||j==10) {
					System.out.print(formatoDecimales.format(Double.parseDouble(nomina[i][j]))+"\t");
				}else {
					System.out.print(nomina[i][j]+"\t\t");
				}
			}
			System.out.print(" |\n");
		}
		System.out.println("------------------------------------------------------------------------------------------------");

	}
	
	
	
	public void imprimirTablaTotalDeducido() {
		System.out.println("\n\n------------------------------------------------------------------------------------------------");
		System.out.println("|                                  "+tablaDeducido[0][2]);
		System.out.println("|"+tablaDeducido[1][0]+"\t|   "+tablaDeducido[1][1]+"   \t|    "+tablaDeducido[1][2]+"    |"+tablaDeducido[1][3]+"  |"+tablaDeducido[1][4]+"|"+tablaDeducido[1][5]+"|"+tablaDeducido[1][6]+" |");
		for(int i=2; i<tablaDeducido.length; i++) {
			for(int j=0; j<tablaDeducido[0].length; j++) {
				if(tablaDeducido[i][j]!="") {
					System.out.print("|");
				}
				if(j>=1) {
					System.out.print(formatoDecimales.format(Double.parseDouble(tablaDeducido[i][j]))+"\t");
				}else {
					System.out.print(tablaDeducido[i][j]+"\t");
				}
				
			}
			System.out.print(" |\n");
		}
		System.out.println("------------------------------------------------------------------------------------------------");
	}
	
}
