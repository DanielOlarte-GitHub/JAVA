package ejercicio9;

public class Modelo {
	String cedula;
	String nombre;
	double salario;
	double auxilioTransporte;
	double dias;
	double sueldo;
	double horasExDiurnas;
	double horasExNocturnas;
	double horasExFestivos;
	double recargoNocturno;
	double totalDevengado;
	double salud;
	double pension;
	double prestamo;
	double fondoSolidaridad;
	double totalDeducido;
	double netoPagar;
	
	public Modelo() {
		
	}
	

	public Modelo(String cedula, String nombre, double salario, double auxilioTransporte, double dias, double sueldo,
			double horasExDiurnas, double horasExNocturnas, double horasExFestivos, double recargoNocturno,
			double totalDevengado, double salud, double pension, double prestamo, double fondoSolidaridad, double totalDeducido,
			double netoPagar) {
		super();
		this.cedula = cedula;
		this.nombre = nombre;
		this.salario = salario;
		this.auxilioTransporte = auxilioTransporte;
		this.dias = dias;
		this.sueldo = sueldo;
		this.horasExDiurnas = horasExDiurnas;
		this.horasExNocturnas = horasExNocturnas;
		this.horasExFestivos = horasExFestivos;
		this.recargoNocturno = recargoNocturno;
		this.totalDevengado = totalDevengado;
		this.salud = salud;
		this.pension = pension;
		this.prestamo = prestamo;
		this.fondoSolidaridad = fondoSolidaridad;
		this.totalDeducido = totalDeducido;
		this.netoPagar = netoPagar;
	}

	public String getCedula() {
		return cedula;
	}

	public void setCedula(String cedula) {
		this.cedula = cedula;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}

	public double getAuxilioTransporte() {
		return auxilioTransporte;
	}

	public void setAuxilioTransporte(double auxilioTransporte) {
		this.auxilioTransporte = auxilioTransporte;
	}

	public double getDias() {
		return dias;
	}

	public void setDias(double dias) {
		this.dias = dias;
	}

	public double getSueldo() {
		return sueldo;
	}

	public void setSueldo(double sueldo) {
		this.sueldo = sueldo;
	}

	public double getHorasExDiurnas() {
		return horasExDiurnas;
	}

	public void setHorasExDiurnas(double horasExDiurnas) {
		this.horasExDiurnas = horasExDiurnas;
	}

	public double getHorasExNocturnas() {
		return horasExNocturnas;
	}

	public void setHorasExNocturnas(double horasExNocturnas) {
		this.horasExNocturnas = horasExNocturnas;
	}

	public double getHorasExFestivos() {
		return horasExFestivos;
	}

	public void setHorasExFestivos(double horasExFestivos) {
		this.horasExFestivos = horasExFestivos;
	}

	public double getRecargoNocturno() {
		return recargoNocturno;
	}

	public void setRecargoNocturno(double recargoNocturno) {
		this.recargoNocturno = recargoNocturno;
	}

	public double getTotalDevengado() {
		return totalDevengado;
	}

	public void setTotalDevengado(double totalDevengado) {
		this.totalDevengado = totalDevengado;
	}


	public double getSalud() {
		return salud;
	}


	public void setSalud(double salud) {
		this.salud = salud;
	}


	public double getPension() {
		return pension;
	}


	public void setPension(double pension) {
		this.pension = pension;
	}

	public double getPrestamo() {
		return prestamo;
	}


	public void setPrestamo(double prestamo) {
		this.prestamo = prestamo;
	}


	public double getFondoSolidaridad() {
		return fondoSolidaridad;
	}


	public void setFondoSolidaridad(double fondoSolidaridad) {
		this.fondoSolidaridad = fondoSolidaridad;
	}


	public double getTotalDeducido() {
		return totalDeducido;
	}


	public void setTotalDeducido(double totalDeducido) {
		this.totalDeducido = totalDeducido;
	}


	public double getNetoPagar() {
		return netoPagar;
	}


	public void setNetoPagar(double netoPagar) {
		this.netoPagar = netoPagar;
	}
	
}
