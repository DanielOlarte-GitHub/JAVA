package ejercicio9;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Vista {
	public static void main(String[] args) throws IOException {

		BufferedReader sc = new BufferedReader(new InputStreamReader(System.in));
		Controlador con = new Controlador();
		// Variables
		int opcion = 1;
		
		while (opcion >= 1 && opcion <= 6) {
			System.out.println("\n\n");
			System.out.println("Universidad ECCI");
			System.out.println("Nomina Empleados");
			System.out.println("Seleccione tarea a realizar:");
			System.out.println("1. Llenar Nomina");
			System.out.println("2. Imprimir Nomina");
			System.out.println("3. Imprimir Tabla Total Deducido");
			System.out.println("0. Salir");
			System.out.println("Digite la Opcion:");
			opcion = Integer.parseInt(sc.readLine());
			switch (opcion) {
				case 1:
					System.out.println("\n\nLLENAR NOMINA");
					con.llenarNomina();
				break;
				
				case 2:
					System.out.println("\n\nIMPRIMIENDO NOMINA\n");
					con.imprimirNomina();
				break;
				
				case 3:
					System.out.println("\n\nIMPRIMIENDO TABLA TOTAL DEDUCIDO\n");
					con.imprimirTablaTotalDeducido();
				break;	
	
				case 0:
					// SALIR
					System.out.println("Hasta Pronto");
					System.exit(0);
	
				default:
					System.out.println("Opcion no valida");
				}
	
			}

	}
}

