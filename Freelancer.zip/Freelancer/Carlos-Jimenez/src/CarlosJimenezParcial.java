
//Parcial hecho por: Carlos Jimenez
import java.util.Scanner;

/*
  5.- Aplicaci�n de calculadora que muestre un men� con las opciones sumar, restar, multiplicar, dividir y salir.

	Suma: solicita los n�meros e imprime el resultado de la suma.
	Resta: se le pasan los n�meros y devuelve el resultado de la resta
	Multiplicaci�n: pide los n�meros por teclado y devuelve el resultado de la multiplicaci�n
	Divisi�n: pide los n�meros por teclado e imprime el resultado de la divisi�n
 */

public class CarlosJimenezParcial {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);//Escanner para recibir los datos digitados por teclado

		int opc;//Variable para la opcion del menu
		double num1, num2, resultado; //Variables para los numeros y el resultado de la calculadora
		String respuesta;//Variable para repetir de nuevo el programa
		System.out.println("�CALCULADORA!\n\n");
		
		do { //Ciclo repetitivo para que sea posible repetir el programa
			//MENU con las opciones a escoger
			System.out.println("\n\n\nMENU:\n");
			System.out.println("1. Sumar");
			System.out.println("2. Restar");
			System.out.println("3. Multiplicar");
			System.out.println("4. Dividir");
			System.out.println("0. Salir");
			System.out.println("Digite que desea realizar? ");
			System.out.print("Opcion: ");
			opc = teclado.nextInt();

			//Switch para que el programa pueda ir por diferentes caminos dependiendo que opcion haya digito por teclado en el menu
			switch (opc) {
			
			case 0://Caso 0 para Cerrar el programa
				System.out.println("\n\n\nCERRANDO EL PROGRAMA!");
				System.exit(0);//Cierra el programa
			break;

			case 1://Caso 1 para Sumar
				//Pide 2 numeros para sumarlos
				System.out.println("\n\nIngrese el primer numero que desee sumar");
				num1 = teclado.nextDouble();
				System.out.println("Ingrese el segundo numero que desee sumar");
				num2 = teclado.nextDouble();
				resultado = num1 + num2;//Suma los 2 numeros digitados por teclado
				System.out.println("\nEL RESULTADO ES: " + resultado);//Imprime el resultado
			break;

			case 2://Caso 2 para Restar
				//Pide 2 numeros para restarlos
				System.out.println("\n\nIngrese el primer numero que desee restar");
				num1 = teclado.nextDouble();
				System.out.println("Ingrese el segundo numero que desee restar");
				num2 = teclado.nextDouble();
				resultado = num1 - num2;//Resta los 2 numeros digitados por teclado
				System.out.println("\nEL RESULTADO ES: " + resultado);//Imprime el resultado
			break;

			case 3://Caso 3 para Multiplicar
				//Pide 2 numeros para multiplicarlos
				System.out.println("\n\nIngrese el primer numero que desee multiplicar");
				num1 = teclado.nextDouble();
				System.out.println("Ingrese el segundo numero que desee multiplicar");
				num2 = teclado.nextDouble();
				resultado = num1 * num2;//Multiplica los 2 numeros digitados por teclado
				System.out.println("\nEL RESULTADO ES: " + resultado);//Imprime el resultado
			break;

			case 4://Caso 4 para Dividir
				//Pide 2 numeros para dividirlos
				System.out.println("\n\nIngrese el primer numero que desee dividir");
				num1 = teclado.nextDouble();
				System.out.println("Ingrese el segundo numero que desee dividirs");
				num2 = teclado.nextDouble();
				resultado = num1 / num2;//Divide los 2 numeros digitados por teclado
				System.out.println("\nEL RESULTADO ES: " + resultado);//Imprime el resultado
			break;

			default://Caso Default para cuando se digite por teclado una opcion que no se las del menu
				System.out.println("\n\nDIGITO UN VALOR INVALIDO INTENTELO DE NUEVO");
			break;
			}

			//Opcion para repetir el programa de nuevo 
			System.out.println("\n\nQuiere repetir el programa? s/n");
			respuesta = teclado.next();
		} while (respuesta.equals("s") || respuesta.equals("S"));
		
		System.out.println("\n\n\nCERRANDO EL PROGRAMA!");
	}
}
