package finalNumeroMayorMenor;

import java.util.Scanner;

public class MayorMenor {
	//Se crean las variables que se van a usar
	static int num1, num2;
	static Scanner teclado = new Scanner(System.in);//Escaner para guardar datos
	
	/**
	 * Metodo para comprobar cual numero es mayor o si son iguales
	 */
	public static void comprobar() {
		System.out.println("\n\n\t\tCOMPROBANDO VALORES\n\n");
		//Condicion para saber si un numero es mayor que otro o si son iguales
		if(num1>num2) {
			System.out.println("\t\tEl numero 1 ("+num1+") es mayor que el numero 2 ("+num2+")");
		}else if(num2 > num1) {
			System.out.println("\t\tEl numero 2 ("+num2+") es mayor que el numero 1 ("+num1+")");
		}else {
			System.out.println("\t\tEl numero 1 ("+num1+") y el numero 2 ("+num2+") son iguales");
		}
	}
	
	/**
	 * Metodo para mostrar los 2 numeros
	 */
	public static void mostrar() {
		System.out.println("\n\n\t\tMOSTRANDO VALORES\n\n");
		System.out.println("\t\tEl valor del numero 1 es: "+num1);
		System.out.println("\t\tEl valor del numero 2 es: "+num2);
	}
	
	/**
	 * Metodo para asignarle los valores a las variables
	 */
	public static void asignar() {
		System.out.println("\n\n\t\tASIGNANDO VALORES\n\n");
		System.out.print("\t\tDigite el valor del numero 1: ");
		num1 = teclado.nextInt();
		System.out.print("\t\tDigite el valor del numero 2: ");
		num2 = teclado.nextInt();
	}
	
	/**
	 * Menu para escoger que opcion se va a realizar
	 */
	public static void menu() {
		System.out.println("\n\n\t\t\t\tMenu\n");
		System.out.println("\t\t1) Digitar los 2 numeros");
		System.out.println("\t\t2) Mostrar los 2 numeros digitados");
		System.out.println("\t\t3) Saber cual es el mayor y cual el menor");
		System.out.println("\t\t0) Salir");
		System.out.print("\n\t\tDIGITE SU OPCION: ");
		int opc = teclado.nextInt();
		
		switch(opc) {
			case 1:
				asignar();
			break;	
			
			case 2:
				mostrar();
			break;
			
			case 3:
				comprobar();
			break;
			
			case 0:
				System.out.println("\t\tSaliendo del programa\n\n");
				System.exit(0);
			break;
			
			default:
				System.out.println("\n\t\tDigito un valor incorrecto, intentelo de nuevo");
			break;	
		}
		menu();
	}
	
	/**
	 * Metodo Principal del codigo
	 */
	public static void main(String[] args) {
		System.out.println("\n\n\t\tEjercicio para saber cual numero es mayor o menor");
		menu();
	}
}
